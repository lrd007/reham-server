@extends('frontend.layouts.master')
@section('content')
    <!--Login Body-->
    <Section class="LoginBody py-3 text-center " id="LoginBody">

        @if(Config::get('app.locale')=='ar')
            <img src="{{asset('frontend/images/reham-logo-arabic-white.png')}}" alt="logo" class="logo">
            <img src="frontend/images/LoginBg.svg" alt="LoginBg" style="right: 20%;transform: rotate(360deg);">
        @else

            <img src="{{asset('frontend/images/logo.svg')}}" alt="logo" class="logo">
            <img src="frontend/images/LoginBg.svg" alt="LoginBg">
        @endif

        <div class="container-fluid">
            <div class="row ">
                <div class="col-12  d-flex  justify-content-center">
                    <div class="LoginForm RightBottomCorner  ">
                        <h4 class="ms-5"><b>{{__('words.Create a new account')}}  </b></h4>

                        <p class="ms-5">{{__('words.It’s free and always will be.')}}</p>
                        <!-- <form class="mt-4 text-center" action="{{ url('/register_post') }}" method="post"> -->
                        <form class="mt-4 text-center" action="{{ route('signup.post') }}" method="post">
                            @csrf
                            <div class="mb-3  position-relative">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-person-circle" viewBox="0 0 16 16">
                                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                    <path fill-rule="evenodd"
                                        d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                </svg>
                                <input name="first_name" type="text" class="form-control" id="FirstName"
                                    aria-describedby="FirstName" placeholder="{{ __('words.First Name') }}" required>
                            </div>

                            <div class="mb-3  position-relative">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-person-circle" viewBox="0 0 16 16">
                                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                    <path fill-rule="evenodd"
                                        d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                </svg> <input name="last_name" type="text" class="form-control" id="LastName"
                                    aria-describedby="LastName" placeholder="{{ __('words.Last Name') }}" required>
                            </div>
                            <div class="mb-3  position-relative">
                                <i class="fa-regular fa-flag"></i>
                                <select name="country_id" class="form-select" aria-label="Default select example"
                                    id="Country">
                                    @foreach ($countries as $country)
                                        <option value="{{ $country->id }}">{{ $country->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3  position-relative">
                                <i class="fa-solid fa-grip-vertical"></i>
                                <input name="mobile_number" type="phone" class="form-control" id="PhoneNumb"
                                    aria-describedby="PhoneNumb" placeholder="{{ __('words.Phone number') }}" required>
                            </div>
                            <div class="mb-3  position-relative">
                                <i class="fa-regular fa-envelope"></i>
                                <input name="email" type="email" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" placeholder="{{ __('words.Email') }}" required>
                            </div>
                            <div class="mb-3  position-relative">
                                <i class="fa-regular fa-envelope"></i>
                                <input name="email_confirm" type="email" class="form-control" id="exampleInputEmail2"
                                    aria-describedby="emailHelp" placeholder="{{ __('words.Confirm Email') }}" required>
                            </div>
                            <div class="mb-4 position-relative">
                                <img src="frontend/images/password Icon.svg" alt="password Icon">

                                <input name="password" type="password" class="form-control password"
                                    id="exampleInputPassword1" placeholder="{{ __('words.Password') }}" required>
                                <i class="fa-solid fa-eye float-end Showpass"></i>
                            </div>
                            <button type="submit" class="btn btn-primary  position-relative ">{{ __('words.Register') }}</button>
                        </form>
                        <p class=" text-center mt-3" id="LoginOrRegister">{{ __('words.Already Have an account') }} <span><a
                                    href="{{ route('user.login') }}">{{ __('words.Login') }}</a></span></p>
                    </div>
                </div>
            </div>
        </div>
    </Section>

    <!--End Login Body-->
@endsection
