@extends('frontend.layouts.master')
@section('content')
<!--Login Body-->
<Section class="LoginBody py-3 text-center " id="LoginBody">
  <img src="{{ asset('frontend/images/logo.svg')}}" alt="logo" class="logo">
  <img src="{{ asset('frontend/images/LoginBg.svg')}}" alt="LoginBg">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-12  d-flex  justify-content-center">
        <div class="LoginForm RightBottomCorner  ">
          <h4 class="mb-5 text-center"><b>{{ __('words.Reset Password') }} </b></h4>

          <form action="{{ route('forgot_password_link') }}" method="POST" class="mt-4 text-center">
            <div class="mb-3 position-relative">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
              </svg>
              <input type="email" name="email" class="form-control" id="email" aria-describedby="email" placeholder="{{ __('words.Email') }}" required>
            </div>

            <!-- <div class="mb-4 position-relative">
              <img src="frontend/images/password Icon.svg" alt="password Icon">
              <input type="password" class="form-control password" id="exampleInputPassword1" placeholder="New Password" required>
              <i class="fa-solid fa-eye float-end Showpass"></i>
            </div>

            <div class="mb-4 position-relative">
              <img src="frontend/images/password Icon.svg" alt="password Icon">
              <input type="password" class="form-control password" id="exampleInputPassword2" placeholder="Confirm New Password" required>
            </div> -->
            <button type="submit" class="btn btn-primary  position-relative ">{{ __('words.Forget Password') }}</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</Section>

<!--End Login Body-->
@endsection
