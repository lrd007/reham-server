@extends('frontend.layouts.master')
@section('auth_content')
<!--Payment Body-->
<section class="Profile" id="Profile">
  <div class="container-fluid">
    <div class="row PayemntMethod">
      <div class="col-md-5 py-5 px-4 ProfileInfo  d-flex justify-content-center align-items-center">
        <img src="frontend/images/Payment Image.png" alt="Payment Method Image" class="w-75">

      </div>
      <div class="col-md-7 py-5 ProfileForm">
        <div class="GreyTitle">Paypal</div>
        <form class="PaymentForm">
          <div class="row">

            <div class="col-md-6 px-3 mb-4">
              <label for="CardNumber" class="form-label" style="color: #939597;"><b> Card Number</b></label>
              <input type="number" class="form-control" id="CardNumber" aria-describedby="CardNumber" required>
            </div>
            <div class="col-md-6 px-3 mb-4">
              <label for="CVV" class="form-label" style="color: #939597;"><b>CVV</b></label>
              <input type="number" class="form-control" id="CVV" aria-describedby="CVV" required>
            </div>
            <div class="col-md-6 px-3 mb-4">
              <label for="ExpiresDate" class="form-label" style="color: #939597;"><b>Expires</b></label>
              <input type="date" class="form-control" id="ExpiresDate" aria-describedby="ExpiresDate" value="" required>
            </div>
            <div class="col-md-6 px-3 mb-4">
              <label for="BillignAddress" class="form-label" style="color: #939597;"><b>Billign
                  Address</b></label>
              <input type="text" class="form-control" id="BillignAddress" aria-describedby="BillignAddress" required>

            </div>


          </div>

        </form>

      </div>
    </div>

  </div>
  <div class="col-8 offset-4">
    <button type="submit" class="btn btn-primary"><b>Attach </b> </button>

    <button type="button" class="btn btn-primary float-end AnotherMethod mb-5"><i class="fa-solid fa-plus me-2"></i> Add Another
      Payment
      Method </button>
  </div>
</section>
<!--End Payment Body-->
@endsection