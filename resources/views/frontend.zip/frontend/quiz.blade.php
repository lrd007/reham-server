@extends('frontend.layouts.master')
@section('auth_content')
<!--Quiz Body-->
<section class="Profile" id="Profile">
    <div class="container">
        <div class="row">

            <div class="col-12 py-5 ProfileForm">
                <div class="container-fluid">
                    <div class="row Quiz1">
                        <div class="QuizText">
                            <p>Quiz#1 Lorem Ipsum Dolor Sit Amet, Consetetur</p>
                            <p>10. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
                                nonumy
                                eirmod tempor invidunt ut labore ?</p>
                        </div>
                        <div class="container px-5">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                <label class="form-check-label" for="exampleRadios1">
                                    <p> Default radio</p>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                                <label class="form-check-label" for="exampleRadios2">
                                    <p>Second default radio</p>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3">
                                <label class="form-check-label" for="exampleRadios3">
                                    <p>Second default radio</p>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row Quiz2 mt-5">
                        <div class="QuizText">
                            <p>Quiz#2 Lorem Ipsum Dolor Sit Amet, Consetetur</p>
                            <p>11. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
                                nonumy
                                eirmod tempor invidunt ut labore ?</p>
                        </div>
                        <form>
                            <div class="row">
                                <div class="col-12 px-3 mb-4">

                                    <textarea name="Message" id="Message" class="form-control p-5" cols="30" rows="10" required placeholder="Description"></textarea>
                                </div>

                            </div>

                        </form>
                    </div>
                    <button type="submit" class="btn btn-primary  mt-5 mx-auto d-flex" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#QuizResultModal"><b>Submit Answers </b> </button>
                    <!--Quiz results -->
                    <div class="modal fade" id="QuizResultModal" tabindex="-1" aria-labelledby="QuizResultModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content p-sm-5  RightTopCorner">
                                <div class="modal-header">
                                    <a type="button" href="LandingPageAfterLogin.html" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-x"></i></a>
                                </div>
                                <div class="modal-body text-center p-sm-4">
                                    <h5 class="my-4" style="color: #939597; line-height: 35px;"><b>Well
                                            done! You’ve
                                            successfully
                                            passed quiz with 90.And an Email
                                            has been sent to your address. </b></h5>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<!--End Quiz Body-->
@endsection