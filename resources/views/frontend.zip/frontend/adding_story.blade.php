@extends('frontend.layouts.master')
@section('auth_content')
<!--Upload Story Body-->
<section class="UploadStoryBody">
    <div class="container py-5">

        <form action="LandingPageAfterLogin.html" class="UploadStoryForm d-flex flex-column justify-content-center align-content-center text-center px-md-5">
            <label for="UploadStoryBtn" class="px-5  mb-5 align-self-center UploadBtn"><i class="fa-solid fa-plus me-3"></i> Upload
                Your Story </label>
            <input type="file" name="UploadStoryBtn" id="UploadStoryBtn" hidden>

            <div class="iframeContainer">
                <iframe src="https://player.vimeo.com/video/253989945" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
            </div>
            <textarea name="Description" id="StoryDescription" cols="30" rows="10" placeholder="Description" class="Description py-4 px-5 mt-4" required></textarea>
            <label for="UploadFileSelect" class=" mt-4 mb-3 ms-5 float-start UploadSelectLabel">Upload
                File</label>
            <select class="form-select form-select-lg mb-3 px-5 py-3" aria-label=".form-select-lg example" id="UploadFileSelect" required>
                <option selected>Upload from computer </option>
                <option value="1">Upload from url</option>
            </select>
            <div class="form-check text-start mt-4 px-5">
                <input class="form-check-input me-3" type="checkbox" value="" id="flexCheckChecked" checked required>
                <label class="form-check-label" for="flexCheckChecked">
                    I accept all terms and conditions.
                </label>
            </div>
            <button type="submit" class="btn btn-primary px-5  mt-5 align-self-center UploadBtn">
                Submit </button>
        </form>

    </div>
</section>
<!--End Upload Story Body-->
@endsection