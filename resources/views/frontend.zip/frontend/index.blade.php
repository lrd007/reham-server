@extends('frontend.layouts.master')

@auth
    @section('auth_content')
        @endauth

        @guest
            <!-- ❕❕❕❕❕❕hero❕❕❕❕❕❕ -->
            <div class="home__hero">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="video__player" id="videoContainer">
                                <button class="play__video" id="playBtnIcon">
                                    <i class="fa-solid fa-circle-play"></i>
                                </button>
                                <video
                                    id="heroVideo"
                                    class="d-none"
                                    controls
                                    preload="auto"
                                    width="1200"
                                    height="620"
                                >
                                    <source src="./assets/video/pexels-alleksana-6561997-426x238-25fps.mp4" type="video/mp4" />
                                    <source src="./assets/video/pexels-alleksana-6561997-426x238-25fps.mp4" type="video/webm" />
                                    <p class="vjs-no-js">
                                        To view this video please enable JavaScript, and consider upgrading to a
                                        web browser that
                                        <a href="https://videojs.com/html5-video-support/" target="_blank"
                                        >supports HTML5 video</a
                                        >
                                    </p>
                                </video>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ❗❗❗❗❗❗hero❗❗❗❗❗❗ -->

        @endguest

        @auth()
            <!-- ❕❕❕❕❕❕slider❕❕❕❕❕❕ -->
            <div class="home__slider">
                <div class="container">
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="d-block w-100" src="../assets/images/home-slider-image.png"
                                     alt="First slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="../assets/images/home-slider-image.png"
                                     alt="Second slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="../assets/images/home-slider-image.png"
                                     alt="Third slide">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button"
                           data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button"
                           data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
            <!-- ❗❗❗❗❗❗slider❗❗❗❗❗❗ -->
        @endauth


            @section('content')

                <!-- ❕❕❕❕❕❕programes❕❕❕❕❕❕ -->
                <div class="home__programes">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="programes__header">
                                    <h2 class="_heading">{{ __('words.Programs') }}</h2>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="row">
                                    @foreach($programs as $program)
                                        @if($program->in_home_page == true)
                                            <div class="col-12 col-6 col-md-4">
                                                <div class="program__card text-center d-flex flex-column justify-content-center align-items-center">
                                                    <h3 class="program__header">{{ $program->{ 'name'. withLocalization() } }}</h3>
                                                    <img src="{{url(uploads_images('program', null,true) . '/' . $program->thumb_image)}}"
                                                         alt="{{ $program->{ 'name'. withLocalization() } }}" class="program__img img-fluid">
                                                    <p class="about__program">
                                                        {{ $program->{ 'caption'. withLocalization() } }}
                                                    </p>
                                                    <a class="program__btn" href="{{route('program_details',['program'=>$program->id])}}">{{__('words.View')}}</a>
                                                </div>
                                            </div>
                                        @endif
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ❗❗❗❗❗❗programes❗❗❗❗❗❗ -->

                <!-- ❕❕❕❕❕❕news-latter❕❕❕❕❕❕ -->
                <div class="newslatter">
                    <div class="container">
                        <div class="row align-items-center justify-content-center">

                            <div class="col-md-6 col-12">
                                <div class="newslatter__right  d-flex align-items-center  justify-content-center">
                                    <p class="newslatter__content">
                                        {{ __('words.home-text') }}
                                    </p>
                                </div>
                            </div>

                            @guest()
                                <div class="col-md-6 col-12">
                                    <div class="newslatter__left d-flex align-items-center  justify-content-center flex-column text-center">
                                        <h3 class="heading"> {{ __('words.Stay In Touch With Us') }}</h3>
                                        <form class="newslatter__form d-flex align-items-center  justify-content-center flex-column text-center ">
                                            <div class="input__container">
                                                <input type="email" placeholder="{{ __('words.Insert Email') }}" class="input__email">
                                            </div>
                                            <div class="input__container">
                                                <input type="submit" value="{{ __('words.Subscriber Now') }}" class="sumbit__input" >
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            @endguest

                            @auth()
                                <div class="col-md-6 col-12">
                                    <div class="newslatter__left d-flex align-items-center  justify-content-center flex-column text-center">
                                        <h3 class="heading">
                                            @if((Config::get('app.locale')=='ar'))
                                                {{ \Carbon\Carbon::parse(now())->translatedFormat('d M ')}}
                                                <br />
                                                {{ \Carbon\Carbon::parse(now())->translatedFormat('l ')}}
                                            @else
                                                {{ \Carbon\Carbon::parse(now())->translatedFormat('d M ')}}
                                                <br />
                                                {{ \Carbon\Carbon::parse(now())->translatedFormat('l ')}}

                                            @endif
                                        </h3>
                                    </div>
                                </div>
                            @endauth


                        </div>
                    </div>
                </div>
                <!-- ❗❗❗❗❗❗news-latter❗❗❗❗❗❗ -->

            @endsection
