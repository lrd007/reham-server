@extends('frontend.layouts.master')
@auth
@section('auth_content')
@endauth

@guest
@section('content')
@endguest
<!--Login Body-->
<Section class="LegalBody  py-5 my-5" id="LegalBody">

<div class="container-fluid">
  <div class="GreyTitle">
    {{__('words.Legal FAQs')}}
  </div>
  <!--Accordion-->
  <div class="accordion" id="accordionPanelsStayOpenExample">
    @foreach($legal_faqs as $legal_faq)
    <div class="accordion-item mb-4">
      <h2 class="accordion-header" id="panelsStayOpen-headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse"
          data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true"
          aria-controls="panelsStayOpen-collapseOne">
          {{ $legal_faq->{ 'question'. withLocalization() } }}
        </button>
      </h2>
      <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show"
        aria-labelledby="panelsStayOpen-headingOne">
        <div class="accordion-body">
        {!! $legal_faq->{ 'answer'. withLocalization() } !!}
        </div>
      </div>
    </div>
    @endforeach
  </div>
</div>
</Section>

<!--End Login Body-->
@endsection
