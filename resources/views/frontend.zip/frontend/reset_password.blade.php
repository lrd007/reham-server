@extends('frontend.layouts.master')
@section('auth_content')
<!--Reset Password Body-->
<section class="Profile" id="Profile">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-5 py-5 px-4 ProfileInfo  text-center">
                <div class="circle mx-auto mb-4">
                    <img src="frontend/images/logo.svg" alt="ProfilePhoto">
                </div>
                <div class="ProfileName GreyTitle mb-3 ">Vincent Coleman</div>
                <h2 class="ProfileEmail " style="color: #939597;">vincent@gmail.com</h2>
            </div>
            <div class="col-md-7 py-5 ProfileForm">
                <div class="GreyTitle mb-4">Reset Password</div>
                <form>
                    <div class="row">
                        <div class="col-md-10 px-3 mb-4">
                            <label for="OldPassword" class="form-label" style="color: #939597;"><b>Old
                                    Password</b></label>
                            <input type="password" class="form-control" id="OldPassword" aria-describedby="OldPassword" value="">
                        </div>
                        <div class="col-md-10 px-3 mb-4">
                            <label for="NewPassword" class="form-label" style="color: #939597;"><b>New
                                    Password</b></label>
                            <input type="password" class="form-control" id="NewPassword" aria-describedby="NewPassword" value="">
                        </div>
                        <div class="col-md-10 px-3 mb-4">
                            <label for="ConfirmPassword" class="form-label" style="color: #939597;"><b>Confirm
                                    Password</b></label>
                            <input type="password" class="form-control" id="ConfirmPassword" aria-describedby="ConfirmPassword" value="">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary "><b>Save Changes </b> </button>


                </form>
            </div>
        </div>
    </div>
</section>
<!--End Reset Password Body-->
@endsection