@extends('frontend.layouts.master')
@section('auth_content')
<!--Course One-->
<section class="Courses py-5 px-md-3">
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="#">{{ __('words.My Programs') }}</a></li>
                <li class="breadcrumb-item"><a href="#">Course 1</a></li>
            </ol>
        </nav>
        @if(isset($program))
            <div class="GreyTitle mb-2">
                Course 1
            </div>
            <h3 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing
                Elitr, Sed Diam
            </h3>
            <h6 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr,
                Sed
                Diam Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam
                Voluptua. At Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita Kasd
                Gubergren, No Sea Takimata Lorem Ipsum
            </h6>
            <div class="row mb-3 mt-5">
                <div class="col-md-6 col-12 d-flex flex-column align-items-center ChapterDescription">
                    <h2 class="ChapterNumber text-start w-100">Lesson 1</h2>
                    <p>
                        Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr, Sed Diam Nonumy
                        Eirmod
                        Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam Voluptua.
                        At
                        Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita Kasd
                        Gubergren,
                        No Sea Takimata
                    </p>

                </div>
                <div class="col-md-3 col-6 ChapterDetails d-flex align-items-center">
                    <p class="mb-0">
                        completed
                        <br>
                        <span class="ChapterComplitationPercentage">70%</span>
                    </p>
                </div>
                <div class="col-md-3 col-6 ChapterDetails d-flex align-items-center">
                    <p class="mb-0">
                        duration
                        <br>
                        <span class="ChapterDuration">15Min</span>
                    </p>
                </div>
            </div>
            <div class="row mb-3 mt-5">
                <div class="col-md-6 col-12 d-flex flex-column align-items-center ChapterDescription">
                    <h2 class="ChapterNumber text-start w-100">Lesson 2</h2>
                    <p>
                        Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr, Sed Diam Nonumy
                        Eirmod
                        Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam Voluptua.
                        At
                        Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita Kasd
                        Gubergren,
                        No Sea Takimata
                    </p>

                </div>
                <div class="col-md-3 col-6 ChapterDetails d-flex align-items-center">
                    <p class="mb-0">
                        completed
                        <br>
                        <span class="ChapterComplitationPercentage">40%</span>
                    </p>
                </div>
                <div class="col-md-3 col-6 ChapterDetails d-flex align-items-center">
                    <p class="mb-0">
                        duration
                        <br>
                        <span class="ChapterDuration">45Min</span>
                    </p>
                </div>
            </div>
        @else
            <h3>No Program Deatils</h3>
        @endisset
    </div>
</section>
@endsection
