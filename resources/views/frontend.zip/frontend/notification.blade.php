@extends('frontend.layouts.master')
@section('auth_content')
<!--Notification Body-->
<Section class="NotificationBody  my-5" id="NotificationBody">
    <div class="container-fluid">
        <div class="row">


            <!--Accordion-->
            <div class="col-12">
                <div class="container-fluid">
                    <div class="GreyTitle d-flex  justify-content-between align-items-center">
                        Notifications <button type="button" class="btn btn-dark float-end my-auto" id="ClearAll"><b>
                                Clear All </b></button>

                    </div>
                    @if($notifications->count()>0)
                    <div class="accordion" id="accordionPanelsStayOpenExample">
                        @foreach($notifications as $notification)
                        <div class="float-end me-3 NotificationTime" style="color:#939597;"><b> {{$notification->created_at->diffForHumans()}} </b></div>
                        <br>
                        <div class="accordion-item mb-4 mt-3">

                            <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="false" aria-controls="panelsStayOpen-collapseOne">
                                    {{$notification->title}}
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse " aria-labelledby="panelsStayOpen-headingOne">
                                <div class="accordion-body">
                                    {!!$notification->message!!}
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    @else
                    <h2 class="text-center NoNotification " style="display: none; color:#939597;">
                        <br>
                        <b> There's No Notification! </b>
                        <br>
                        <p style="font-size:80px;" class="mt-4"> <i class="fa-solid fa-bell-slash"></i>
                        </p>
                    </h2>
                    @endif
                </div>
            </div>
        </div>
    </div>
</Section>

<!--End Notification Body-->
@endsection