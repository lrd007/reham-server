<!DOCTYPE html>
<html lang="{{ (Config::get('app.locale')=='ar') ? 'ar' : 'en' }}">

@include('frontend.partials.head')

<body>

    @include('frontend.partials.navbar')

    @unless (request()->is('course_details')||request()->is('forgot_password'))
        @auth
        <div class="container-fluid px-0" style="margin-top: 50px;">
            <div class="row">
                <div class="col-lg-3">
                    <!--Side Nav Here-->
                  @include('frontend.partials.sidenav')
                    <!--Side Nav Here-->
                </div>
                <div class="col-lg-12">
                    @yield('auth_content')
                </div>
            </div>
        </div>
        @endauth
    @endunless

    @yield('content')

    @include('frontend.partials.footer')
</body>

@include('frontend.partials.scripts')
<script>
    getCartData()
    function getCartData(){
        $.ajax
        ({
            url: '/add-cart',
            type: 'get',
            success: function(result)
            {
                console.log(result.cart_item);
                $('#cart_item').text(result.cart_item);
                // const get_cart = localStorage.getItem('program_details');
                // const program_details = get_cart ? JSON.parse(get_cart) : [];
                // if(program_details.findIndex(e => e === program_id ) == -1) {
                //     program_details.push(program_id);
                // }
                // localStorage.setItem('program_details', JSON.stringify(program_details));
                // const updated_get_cart = localStorage.getItem('program_details');
                // const update_get_cart_count = JSON.parse(updated_get_cart).length;
            }
        });
        // const get_cart = localStorage.getItem('program_details');
        // const update_get_cart_count = JSON.parse(get_cart).length;
        // $('#cart_item').text(update_get_cart_count);
    }
    function passwordHideshow(data) {
      console.log(data);
      var val = document.getElementById("#password").getAttribute();
      console.log(val);
    }
</script>
</html>
