@extends('frontend.layouts.master')
@section('content')
<!--Login Body-->
<Section class="LoginBody py-3 text-center " id="LoginBody">

    @if(Config::get('app.locale')=='ar')
        <img src="{{asset('frontend/images/reham-logo-arabic-white.png')}}" alt="logo" class="logo">
        <img src="frontend/images/LoginBg.svg" alt="LoginBg" style="right: 20%;transform: rotate(360deg);">
    @else

        <img src="{{asset('frontend/images/logo.svg')}}" alt="logo" class="logo">
        <img src="frontend/images/LoginBg.svg" alt="LoginBg">
    @endif


  <div class="container-fluid">
    <div class="row ">
      <div class="col-12  d-flex  justify-content-center">
        <div class="LoginForm RightBottomCorner  ">
          <h4 class="ms-4"><b style="font-size: clamp(1.7rem,4vw,2.6875rem)"> {{ __('words.Glad To See You') }} </b></h4>

          <p class="ms-4">{{ __('words.login hint') }} </p>
          <form action="{{ route('user.login') }}" method="POST" novalidate class="mt-4 text-center">
            @csrf
            <div class="mb-4  position-relative">
              <i class="fa-regular fa-envelope"></i>
              <input name="email" type="email" class="form-control @if ($errors->has('email')) is-invalid @endif" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="{{ __('words.Email') }}" required>
              @if ($errors->has('email'))
              <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('email') }}</strong>
              </span>
              @endif
            </div>
            <div class="mb-3 position-relative">
              <img src="{{ asset('frontend/images/password Icon.svg') }}" alt="password Icon">

              <input name="password" id="password" type="password" class="form-control password  @if ($errors->has('password')) is-invalid @endif" id="exampleInputPassword1" placeholder="{{__('words.Password')}}" required>
              <!-- <i class="fa-solid fa-eye float-end Showpass" onclick="passwordHideShow('hello')"></i> -->
              @if ($errors->has('password'))
              <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('password') }}</strong>
              </span>
              @endif
            </div>
            <p class="float-start my-3"><a href="{{route('forgot_password_page')}}"><b>{{ __('words.Forget Password') }} </b></a></p>
            <button type="submit" class="btn btn-primary  position-relative ">{{ __('words.Login') }} <i class="fa-solid fa-right-to-bracket"></i></button>
          </form>
          <p class=" text-center mt-3" id="LoginOrRegister">{{ __('words.You don not Have an account') }} <span><a href="{{route('signup')}}">{{ __('words.Register here') }}</a></span></p>

        </div>
      </div>
    </div>
  </div>
</Section>


<!--End Login Body-->
@endsection
