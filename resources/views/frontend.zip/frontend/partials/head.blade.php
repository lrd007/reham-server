<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="theme-color" content="#ff99ca">
    <link rel="apple-touch-icon" href="{{ asset('assets/favicon_io/logo192.png.html') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('assets/favicon_io/apple-touch-icon.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('assets/favicon_io/favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/favicon_io/favicon-16x16.png') }}">
    <link rel="manifest" href="{{ asset('assets/favicon_io/favicon-32x32.png') }}">




    <link rel="stylesheet" href="{{asset('frontend/assets/css/fontawesome.min.css')}}">

    <link rel="stylesheet" href="{{asset('frontend/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/main.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/pages/home.css')}}">
    @if ( Config::get('app.locale')=='en' )
        <link rel="stylesheet" href="{{asset('frontend/assets/css/bootstrap.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/css/pages/home-ltr.css')}}">
    @endif
    @if ( Config::get('app.locale')=='ar' )
        <link rel="stylesheet" href="{{asset('frontend/css/styleAr.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/bootstrap.rtl.css')}}">

    @endif
    <title>
    @if(isset($title)){{ $title }}@else{{ __('words.Homepage') }}@endif - {{ env('APP_NAME') }}
    </title>
    <!-- ⏺️⏺️ JQuery⏺️⏺️  -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Google Adsense -->
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4329668470911271"
            crossorigin="anonymous"></script>
    <!-- End Google Adsense -->
    <!-- Meta Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '206581309754665');
        fbq('track', 'PageView');
    </script>
    <noscript>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=206581309754665&ev=PageView&noscript=1"/>
    </noscript>
    <!-- End Meta Pixel Code -->
@if(Route::currentRouteName() == 'index')

<style>
    /* Slider */

    .video__player {
        background-color: #fff;
        border-radius: 150px;
        padding: 15px;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 600px;
        border-top-right-radius: 0;
        width: 100%;
    }
    .video__player .active {
        background: none;
    }
    .video__player .play__video {
        cursor: pointer;
        background: none;
        border: none;
    }
    .video__player .play__video .fa-solid {
        font-size: 4.5rem;
        color: #eb8eba;
        border: 2px solid transparent;
        border-radius: 50%;
        transition: all 0.8s;
    }
    .video__player .play__video .fa-solid:hover {
        color: #efbed6;
        border-color: #f07bb2;
    }
    .video__player video {
        width: 100% !important;
        height: 50% !important;
    }
    @media screen and (max-width: 768px) {
        .video__player {
            border-radius: 70px;
            height: 400px;
        }
    }

    #playBtnIcon {
        background-color: transparent;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-image: url('https://cliprz.org/playBtnTag.svg');
        background-repeat: no-repeat;
        background-size: 46px;
        background-position: 50% calc(50% - 10px);
        border: none !important;
        box-shadow: none !important;
    }
    #playBtnIcon:before {
        content: "";
        display: none;
    }
    #playBtnIcon:hover {
         background-color: transparent;
         opacity: .7;
     }

</style>
    @endif
</head>
