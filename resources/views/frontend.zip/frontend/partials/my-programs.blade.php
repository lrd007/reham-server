@foreach ($user->subscriber->subscribePrograms as $program_data)

    @if(!in_array($program_data->program_id,$ids))

        @php
            $program_id = $program_data->program_id;
            array_push($ids, $program_id);
            $program = Modules\Program\Entities\Program::find($program_id);

            $program_name = $program ? $program->name_en : NULL;
            if(Config::get('app.locale')=='ar'){
                $program_name = $program ? $program->name_ar : NULL;
            }
        @endphp

        @if($program_name != NULL)

            @foreach ($program->courses as $course)
                <li class="acrodding__item">
                    <div class="side__according">
                        <div class="according__title">
                            @php
                                $course_name = $course->name_en;
                                if(Config::get('app.locale')=='ar'){
                                    $course_name = $course->name_ar;
                                }
                            @endphp
                            <button
                                class="toggle__btn d-flex align-items-center  justify-content-between toggle__according"
                                data-index="according-{{($course->id+100)}}">

                                <a href="{{route('single-program',['program_id' => $program_id])}}">{{$course_name}}</a>

                                <i class="fa-solid fa-chevron-down"></i>
                            </button>

                        </div>
                        <div class="according__body" id="according-{{($course->id+100)}}">
                            <ul class="list-unstyled acrodding__list">
                                @foreach ($course->chapters as $chapter)
                                    @php
                                        $chapter_name = $chapter->name_en;
                                        if(Config::get('app.locale')=='ar'){
                                            $chapter_name = $chapter->name_ar;
                                        }
                                    @endphp
                                    <li class="acrodding__item">
                                        <a href="{{route('lesson-details',['program_id' => $program_id , 'course_id' => $course->id , 'chapter_id' => $chapter->id ])}}">
                                            {{ $chapter_name }}
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </li>
            @endforeach
        @endif
    @endif
@endforeach
