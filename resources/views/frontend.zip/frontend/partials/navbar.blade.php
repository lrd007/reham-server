<!-- ❕❕❕❕❕❕navbar❕❕❕❕❕❕ -->
<div class="nav__bar">
    <nav class="reham__navbar">
        <div class="container">
            <div class="row justify-content-between justify-content-md-start align-items-center">
                <div class="col-11 col-lg-1">
                    <div class="nav__brand">
                        <!-- switch AR ✨✨ -->
                        <a href="{{route('index')}}">

                            @if(Config::get('app.locale')=='ar')
                                <img id="navLogo" src="{{asset('frontend/images/reham-logo-arabic-white.png')}}"
                                     alt="logo" class="nav__logo img-fluid"/>
                            @else
                                <img id="navLogo" src="{{asset('frontend/images/logo.svg')}}" alt="logo"
                                     class="nav__logo img-fluid"/>
                            @endif
                        </a>
                    </div>
                </div>
                <div class="col-lg-11 col-1  justify-content-end toggle__btn" id="toggleNavBtn">
                    <i class="fa-solid fa-bars"></i>
                </div>
                <div class="col-10 col-md-11 toggle_nav">
                    <div class="navbar__items__container">
                        <ul class="list-unstyled nav__items  d-flex align-items-center">
                            <li class="nav__item">
                                <div class="dropdown">
                                    <button class="btn  dropdown-toggle dropdown__btn" id="dropdownProgram"
                                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        {{__('words.Programs')}}
                                    </button>
                                    <ul class="dropdown-menu">
                                        @foreach($programs as $program)
                                            @php
                                                $program_name = (Config::get('app.locale' ) == 'ar') ? $program->name_ar : $program->name_en ;
                                            @endphp
                                            <li>
                                                <a class="dropdown-item" href="{{route('program_details',['program'=>$program->id])}}">{{ $program_name }}</a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </li>

                            <li class="nav__item nav__search">
                                <form>
                                    <div class="input__container">
                                        <i class="fa-solid fa-magnifying-glass _search-icon"></i>
                                        <input type="search" placeholder="{{__('words.Search Courses')}}" id="searchGroup"
                                               class="form__input"/>
                                        <i class="fa-solid fa-xmark _cancel-icon"></i>
                                    </div>
                                </form>
                            </li>
                           {{-- <li class="nav__item toggle__lang d-flex align-items-center">
                                <i class="fa-solid fa-toggle-on"></i>
                                <a href="#" onclick="setLng('en')" id="toggleLng">
                                    English
                                </a>
                            </li>
--}}
                            @if ( Config::get('app.locale')=='ar' )
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked"
                                           @if ( Config::get('app.locale')=='ar' )checked @else
                                        ''
                                    @endif>
                                    <label class="form-check-label" for="flexSwitchCheckDefault">English</label>
                                </div>
                            @else
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked"
                                           @if ( Config::get('app.locale')=='ar' )checked @else
                                        ''
                                    @endif>
                                    <label class="form-check-label" for="flexSwitchCheckDefault">عربي</label>
                                </div>
                            @endif
                            @auth

                            <li class="nav__item nav__cart">
                                <i class="fa-solid fa-cart-shopping"></i>
                                <a href="{{route('cart')}}>
                                     {{__('words.Cart')}}
                                </a>
                            </li>

                            <li class="nav__item nav__notifiction d-flex align-items-center justify-content-around">
                                <a href="{{route('notification')}}">
                                    <i class="fa-solid fa-bell"></i>
                                    <span>{{Auth::user()->notifications->count()}}</span>
                                </a>
                                <a href="/">
                                    <i class="fa-solid fa-envelope"></i>
                                    <span>{{Auth::user()->notifications->count()}}</span>
                                </a>
                            </li>

                            <li class="nav__item user__state">
                                <div class="user__card d-flex align-items-center">
                                    <i class="fa-sharp fa-solid fa-chevron-down"></i>
                                    <button type="button" class="btn user__btn btn-primary" data-toggle="modal"
                                            data-target="#exampleModal">
                                        {{Auth::user()->name}}
                                    </button>
                                    <i class="fa-sharp fa-solid fa-user"></i>
                                </div>
                            </li>
                            @endauth
                            @guest
                                <li class="nav__item nav__cart">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                    <a href="{{route('cart')}}">
                                     {{__('words.Cart')}}
                                    </a>
                            </li>
                            <li class="nav__item nav__login">
                                <a href="{{route('user.login')}}">
                                    {{__('words.Login')}}
                                </a>
                            </li>

                            @endguest
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</div>
<!-- ❗❗❗❗❗❗navbar❗❗❗❗❗❗ -->

@auth()


<!-- ❕❕❕❕❕❕modal user card❕❕❕❕❕❕ -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="user__profile__card ">
                <div class="user_card__container d-flex flex-column">
                    <div >
                        <div class="cancel__icon" >
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <i class="fa-solid fa-square-xmark"></i>
                            </button>
                        </div>
                        <div class="user__info d-flex justify-content-end align-items-center">
                            <div class="user__data">
                                <p class="user__name">{{Auth::user()->name}}</p>
                                <p class="user__email">{{Auth::user()->email}}</p>
                            </div>
                            <div class="user__img">
                                <img src="../assets/icons/profile-picture.svg" alt="">
                            </div>
                        </div>
                        <ul class="list-unstyled user__links">
                            <li class="user__link">
                                <a href="{{route('profile')}}">
                                    {{ __('words.Update Profile') }}
                                </a>
                            </li>
                            <li class="user__link">
                                <a href="{{route('payment')}}">
                                    {{ __('words.Payment Method') }}
                                </a>
                            </li>
                            <li class="user__link">
                                <a href="{{route('legal_faq')}}">
                                    {{ __('words.Change Password') }}
                                </a>
                            </li>
                            <li class="user__link">
                                <a href="{{ route('legal_faq') }}">
                                  {{ __('words.Legal FAQs') }}
                                </a>
                            </li>
                            <li class="user__link">
                                <a href="{{route('technical_support')}}">
                                    {{ __('words.Technical Support') }}
                                </a>
                            </li>
                            <li class="user__link log__out">
                                <form id="logout-form" action="{{ route('user.logout') }}" method="get">
                                    {{ csrf_field() }}
                                <button type="submit" class="btn btn-primary --close--user--list" data-toggle="modal" data-target="#exampleModal2" >
                                    {{ __('words.Log Out') }}
                                </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ❗❗❗❗❗❗modal user card❗❗❗❗❗❗ -->




<!-- ❕❕❕❕❕❕modal user logout❕❕❕❕❕❕ -->
<div class="modal modal-logout fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="logout__pop  flex-column  align-items-center" id="userLogout">
                    <div class="top" id="popCloseBtn">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <i class="fa-solid fa-square-xmark"></i>
                        </button>
                    </div>
                    <div class="pop__up__content d-flex justify-content-center align-items-center flex-column">
                        <p class="heading">{{ __('words.Log Out') }}</p>
                        <p class="body">{{__('words.Are you sure you want to exit.')}}</p>
                        <div class="btns d-flex justify-content-around">
                            <button class="pop__btn">
                                {{ __('words.Yes') }}
                            </button>
                            <button class="pop__btn">
                                {{__('words.No')}}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ❗❗❗❗❗❗user logout❗❗❗❗❗❗ -->
@endauth
