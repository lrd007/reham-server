<!-- ❕❕❕❕❕❕footer❕❕❕❕❕❕ -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-12">
                <div class="footer__logo d-flex align-items-center justify-content-md-start justify-content-center">

                    @if(Config::get('app.locale')=='ar')
                        <img src="{{asset('frontend/images/reham-logo-arabic-white.png')}}" alt="rham" class="img-fluid">
                    @else
                        <img src="{{asset('frontend/images/logo.svg')}}" alt="rham" class="img-fluid">
                    @endif
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="footer__col">
                    <div class="col__heading justify-content-md-start justify-content-center text-md-start text-center  d-flex align-items-center">
                        <i class="fa-solid fa-square-up-right __icon"></i>
                        <p>
                            {{__('words.Useful Links')}}
                        </p>
                    </div>
                    <ul class="list-unstyled d-flex flex-column align-items-md-start align-items-center justify-content-md-start justify-content-center  footer__items">
                        @guest
                        <li class="footer__item">
                            <a href="{{route('user.login')}}" class="footer__link" >{{ __('words.Login') }}</a>
                        </li>
                        <li class="footer__item">
                            <a href="{{route('signup')}}" class="footer__link" >{{__('words.Registerr')}}</a>
                        </li>
                        @endguest
                        @auth()
                                <li class="footer__item">
                                <a href="{{route('user.logout')}}" class="footer__link" >{{__('words.Logout')}}</a>
                                </li>
                        @endauth
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="footer__col">
                    <div  class="col__heading justify-content-md-start justify-content-center text-md-start text-center d-flex align-items-center">
                        {{ __('words.About') }}
                    </div>
                    <ul class="list-unstyled d-flex flex-column align-items-md-start align-items-center justify-content-md-start justify-content-center  footer__items">
                        <li class="footer__item">
                            <a href="{{route('about')}}" class="footer__link" >{{ __('words.About2') }}</a>
                        </li>
                        <li class="footer__item">
                            <a href="{{route('faq')}}" class="footer__link" >{{ __('words.FAQs') }}ً</a>
                        </li>
                        <li class="footer__item">
                            <a href="{{route('legal_faq')}}" class="footer__link" >{{ __('words.Legal') }}</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="footer__col">
                    <div class="col__heading justify-content-md-start justify-content-center text-md-start text-center d-flex align-items-center">
                        {{ __('words.Contact') }}
                    </div>
                    <ul class="list-unstyled d-flex flex-column align-items-md-start align-items-center justify-content-md-start justify-content-center  footer__items">
                        <li class="footer__item">
                            <a href="mailto:hello@reham.com" class="footer__link" >hello@reham.com</a>
                        </li>
                        <li class="footer__item">
                            <a href="tel:+96550406406" class="footer__link" >+96550406406</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-12">
                <div class="footer__bottom text-center">
                    <div class="d-flex align-items-center justify-content-center social-links">
                        <a href="https://www.facebook.com/Rehamalrashidi/" target="_blank"><img src="../assets/icons/facebook.svg" alt="facebook" class="social-icon"/></a>
                        <a href="https://twitter.com/Rehamalrashidi" target="_blank"><img src="../assets/icons/Twitter.svg" alt="Twitter" class="social-icon"/></a>
                        <a href="#" target="_blank"><img src="../assets/icons/Pinterest.svg" alt="Pinterest" class="social-icon"/></a>
                        <a href="https://www.instagram.com/Rehamalrashidi/" target="_blank"><img src="../assets/icons/Instagram.svg" alt="Instagram" class="social-icon"/></a>
                        <a href="#" target="_blank"><img src="../assets/icons/Google.svg" alt="google" class="social-icon"/></a>
                            <a href="#" target="_blank"><img src="../assets/icons/LinkedIn.svg" alt="LinkedIn" class="social-icon"/></a>
                        <p class="footer__lng">
                            @if ( Config::get('app.locale')=='ar' )
                            العربية (الكويت)
                                @else
                                English (UK)
                            @endif

                        </p>
                    </div>
                    <p class="copy-rights">{{ env('APP_NAME') }} © {{ date('Y') }}
                        &nbsp;<a class="text-decoration-none text-white"
                                 href="https://www.fb.com/fenix.p2h" target="blank">
                            Developed By Muhammad Khalaf</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ❗❗❗❗❗❗footer❗❗❗❗❗❗ -->
