<!-- ❕❕❕❕❕❕sideNav❕❕❕❕❕❕ -->
<div class="side__navbar " id="sidebar">
    <div class="nav__toggler " id="openSidebar">
        <div class="btn__toggler d-flex align-items-center">
            <p>{{ __('words.menu') }}</p>
            <i class="fa-solid fa-arrow-left"></i>
            <i class="fa-solid fa-arrow-right"></i>
        </div>
    </div>
    @auth()
        @php
            $user = auth()->user();
            $ids = [];
        @endphp
        @if(isset($percent))
            <label for="ProgressBar" class="text-center w-100 mb-2 ProgressBarLabel">
                {{ $percent }}%</label>
            <div class="progress   w-75 text-center mx-auto mb-3 ">

                <div class="progress-bar progress-bar-striped bg-success" id="ProgressBar" role="progressbar"
                     style="width: {{ $percent }}%"
                     aria-valuenow="{{ $percent }}" aria-valuemin="0" aria-valuemax="100">

                </div>
            </div>
        @else
            <label for="ProgressBar" class="text-center w-100 mb-2 ProgressBarLabel">
                {{ $user->subscriber->SubscribtionPersent() }}%</label>
            <div class="progress   w-75 text-center mx-auto mb-3 ">

                <div class="progress-bar progress-bar-striped bg-success" id="ProgressBar" role="progressbar"
                     style="width: {{ $user->subscriber->SubscribtionPersent() }}%"
                     aria-valuenow="{{ $user->subscriber->SubscribtionPersent() }}" aria-valuemin="0" aria-valuemax="100">

                </div>
            </div>
        @endif
    @endauth

    <ul class="list-unstyled side__items">
        <li class="side__item">
            <a href="/">
                {{ __('words.Homepage') }}
            </a>
        </li>
        <li class="side__item">
            <div class="side__according">
                <div class="according__title">

                        <button class="toggle__btn d-flex align-items-center  justify-content-between toggle__according" data-index="according-2">
                            <p>
                                <a href="{{route('all_programs')}}" > {{ __('words.My Programs') }}</a>
                            </p>
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>

                </div>
                <div class="according__body" id="according-2">
                    <ul class="list-unstyled acrodding__list">
                        @if (isset($user))
                            @include('frontend.partials.my-programs')
                        @endif
                    </ul>
                </div>



            </div>
        </li>
        <li class="side__item">
            <a href="{{route('wishlist')}}">
                {{ __('words.Whishlist') }}
            </a>
        </li>
        <li class="side__item">
            <a href="{{route('wishlist')}}">
                {{ __('words.Suggested') }} {{ __('words.Courses') }}
            </a>
        </li>
        <li class="side__item">
            <a href="{{route('faq')}}">
                {{ __('words.FAQs') }}
            </a>
        </li>
        <li class="side__item">
            <a href="{{route('calendar')}}">
                {{ __('words.Calendar') }}
            </a>
        </li>
        <li class="side__item --active">
            <a href="{{route('inspiring_stories')}}">
                {{ __('words.Inspiring Stories') }}
            </a>
        </li>
    </ul>
</div>
<!-- ❗❗❗❗❗❗sideNav❗❗❗❗❗❗ -->
