
<script src="{{asset('frontend/assets/js/all.js')}}"></script>
<script src="{{asset('frontend/js/js.js')}}"></script>
<script src="{{asset('frontend/js/SideNavScroll.js')}}"></script>

<!-- bootstrap -->
<script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="{{asset('frontend/js/bootstrap.bundle.js')}}"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>



<!-- ⏺️⏺️ navbnar⏺️⏺️  -->
<script src="{{asset('frontend/js/navbar.js')}}"></script>

<!-- ⏺️⏺️ navbnar⏺️⏺️  -->
<script src="{{asset('frontend/js/according.js')}}"></script>


<script>
    $("#flexSwitchCheckChecked").on('change', function() {
        if ($(this).is(':checked')) {
            location.replace("{{ route('language.change',['locale' => 'ar']) }}");
        } else {
            location.replace("{{ route('language.change',['locale' => 'en']) }}");
        }
    });
</script>

@if(Route::currentRouteName() == 'index')
    <script type="text/javascript">
        playBtnIcon ? playBtnIcon.addEventListener('click', function() {
            heroVideo.classList.remove('d-none');
            heroVideo.play();
            playBtnIcon.classList.add('d-none');
            videoContainer.classList.add('active')
        }) : null;
    </script>
@endif
