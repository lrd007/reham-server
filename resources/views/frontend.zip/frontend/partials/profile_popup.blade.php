<!-- Profile Modal -->
<div class="modal " id="ProfileModal" tabindex="2" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="z-index: 200000 !important;">
        <div class="modal-content  RightTopCorner  p-md-5 ">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-x"></i></button>
            </div>
            <div class="modal-body">
                <div class="card mb-3 border-0">
                    <div class="row g-0">
                        <div class="col-3 d-flex justify-content-center align-items-center title mb-0" style="font-size: 80px;">
                            <div class="circle">
                                <img src="frontend/images/logo.svg" alt="">
                            </div>
                        </div>
                        <div class="col-9">
                            <div class="card-body pe-0 ps-2">
                                <h1 class="card-title GreyTitle"><b>Vincent Coleman</b> </h1>
                                <h5 class="card-text" style="color: #939597;">vincent@gmail.com</h5>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="list-group mt-4">
                    <a href="Profile.html" class="list-group-item list-group-item-action">Update Profile</a>
                    <a href="Payment.html" class="list-group-item list-group-item-action">Payment Method</a>
                    <a href="ResetPassword.html" class="list-group-item list-group-item-action">Change Password</a>
                    <a href="Legal.html" class="list-group-item list-group-item-action">Legal FAQs</a>
                    <a href="TechnicalSupport.html" class="list-group-item list-group-item-action">Technical
                        Support</a>
                    <a href="#" class="list-group-item list-group-item-action" data-bs-toggle="modal" data-bs-target="#LogOutModal" data-bs-dismiss="modal" aria-label="Close">Log Out</a>
                </div>
            </div>

        </div>
    </div>
</div>
<!--LogOut Modal -->
<div class="modal fade" id="LogOutModal" tabindex="-1" aria-labelledby="LogOutModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-5  RightTopCorner">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-x"></i></button>
            </div>
            <div class="modal-body text-center">
                <div class="GreyTitle"> Logout</div>
                <h5 class="my-4" style="color: #939597;">Are you sure you want to exit.</h5>
                <br>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-primary me-5">No</button>
                    <button type="button" class="btn btn-primary">Yes</button>
                </div>
            </div>
        </div>
    </div>
</div>