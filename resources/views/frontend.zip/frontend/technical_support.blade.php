@extends('frontend.layouts.master')
@section('auth_content')
<!--Technical support Body-->
<section class="Profile py-4" id="Profile">
    <div class="container px-2 px-md-auto ">
        <div class="row w-100  d-flex justify-content-center">
            <div class="col-12 w-100 ProfileForm  d-flex flex-column justify-content-center">

                <div class="ProfileName GreyTitle mb-0 ">Technical Support</div>
                <span class="my-3"><a href="mailto:hello@reham.com" class="LinkBtn me-3">Email</a> <a href="https://wa.me/+96550406406" class="LinkBtn">Whatsapp</a> </span>

                <form method="post" action="{{route('technical_support_post')}}">
                    @csrf
                    <div class="row mt-3">
                        <div class="col-12 px-3 mb-4">
                            <label for="Subject" class="form-label" style="color: #939597; font-size: 20px;"><b>
                                    Subject</b></label>
                            <input type="text" class="form-control" id="Subject" aria-describedby="Subject" name="" required>
                        </div>
                        <div class="col-12 px-3 mb-4">
                            <label for="NewPassword" class="form-label" style="color: #939597;font-size: 20px;"><b>Message</b></label>

                            <textarea name="message" id="Message" class="form-control" cols="30" rows="10" required></textarea>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary float-end"><b>Submit </b> </button>
                </form>
            </div>
        </div>
    </div>
</section>
<!--End Technical support Body-->
@endsection