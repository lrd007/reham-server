@extends('frontend.layouts.master')
@section('auth_content')

<!--Profile Body-->
<section class="Profile" id="Profile">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-5 py-5 px-4 ProfileInfo  text-center">
                <div class="changeProfile position-relative w-100">
                    <label class="circle mx-auto mb-4 position-relative" for="UploadPhotoBtn">
                        <img src="frontend/images/logo.svg" alt="ProfilePhoto">
                        <button id="UploadPhotoBtn" type="button" class="btn btn-primary w-100 h-100 position-absolute" hidden data-bs-toggle="modal" data-bs-target="#UploadPhoto">
                            Launch static backdrop modal
                        </button>

                    </label>
                    <div class="modal fade" id="UploadPhoto" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="UploadPhotoLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="text-center w-100" style="color: #767676;"><b> Upload
                                            Image </b></h2>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-x"></i></button>

                                </div>
                                <div class="modal-body p-3">
                                    <div class="UploadImage w-100 h-100 d-flex justify-content-center align-items-center position-relative">
                                        <label for="UploadImageInput" class="w-100 h-100  d-flex justify-content-center align-items-center position-relative">
                                            <h5 class="m-auto"><b> Upload Image</b></h5>
                                        </label>
                                        <input type="file" id="UploadImageInput" class="position-absolute" hidden>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary mx-auto"><b>Save</b>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ProfileName GreyTitle mb-3 ">Vincent Coleman</div>
                <h2 class="ProfileEmail " style="color: #939597;">vincent@gmail.com</h2>
            </div>
            <div class="col-md-7 py-5 ProfileForm">
                <form>
                    <div class="row">
                        <div class="col-md-6 px-3 mb-4">
                            <label for="FirstName" class="form-label" style="color: #939597;"><b> First
                                    Name</b></label>
                            <input type="text" class="form-control" id="FirstName" aria-describedby="FirstName" value="Vincent">
                        </div>
                        <div class="col-md-6 px-3 mb-4">
                            <label for="LastName" class="form-label" style="color: #939597;"><b> Last
                                    Name</b></label>
                            <input type="text" class="form-control" id="LastName" aria-describedby="LastName" value="Coleman">
                        </div>
                        <div class="col-md-6 px-3 mb-4">
                            <label for="DateOfBirth" class="form-label" style="color: #939597;"><b>Date
                                    Of
                                    Birth</b></label>
                            <input type="date" class="form-control" id="DateOfBirth" aria-describedby="DateOfBirth" value="2018-07-22">
                        </div>
                        <div class="col-md-6 px-3 mb-4">
                            <label for="Gender" class="form-label" style="color: #939597;"><b>Gender</b></label>
                            <select class="form-select" aria-label="Default select example" id="Gender">
                                <option selected>Male</option>
                                <option value="1">Female</option>
                                <option value="2">Non-binary</option>
                                <option value="3">Prefer Not to say</option>
                            </select>
                        </div>
                        <div class="col-md-6 px-3 mb-4">
                            <label for="EmailAddress" class="form-label" style="color: #939597;"><b>Email</b></label>
                            <input type="email" class="form-control" id="EmailAddress" aria-describedby="EmailAddress" value="Vincent@gmail.com">
                        </div>
                        <div class="col-md-6 px-3 mb-4">
                            <label for="Nationality" class="form-label" style="color: #939597;"><b>Nationality</b></label>
                            <select class="form-select" aria-label="Default select example" id="Nationality">
                                <option selected>Lebanese</option>
                                <option value="1">Kuwaity</option>
                                <option value="2">Egyptian</option>
                            </select>
                        </div>
                        <div class="col-md-6 px-3 mb-4">
                            <label for="PhoneNumber" class="form-label" style="color: #939597;"><b>Phone
                                    number</b></label>
                            <input type="phone" class="form-control" id="PhoneNumber" aria-describedby="PhoneNumber" value="+312598865477">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary "><b>Save Changes </b> </button>

                </form>
            </div>
        </div>
    </div>
</section>
<!--End Profile Body-->
@endsection