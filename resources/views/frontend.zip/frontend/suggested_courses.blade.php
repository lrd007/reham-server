@extends('frontend.layouts.master')
@section('auth_content')
<!--Suggestions-->
<section class="SuggestionsSection px-md-3 py-5">
    <div class="container-fluid">
        <div class="GreyTitle mb-5">
            Suggestions
        </div>
        <section class="Suggestions specialOffer mb-5" id="WhishList">
            <div class="row">
                <!-- Cards-->

                <div class="card-group SuggestionsCardGroup">
                    <div class="col-md-4 p-2">
                        <div class="card ">
                            <img src="frontend/images/SpecialOfferCardIconWhite.svg" alt="Special Offers Card Icon">
                            <div class="card-body">
                                <h5 class="card-title px-3"><span class="SuggestionsFaV float-start"><i class="fa-solid fa-heart"></i></span> Program 1
                                    <span class="SuggestionsAddToCart  float-end"><i class="fa-solid fa-cart-shopping"></i></span>
                                </h5>

                                <p>UI UX Design Fundemantals</p>
                                <a href="CourseDetailes.html"><button type="button" class="btn btn-outline-light">Course Detail</button></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 p-2">
                        <div class="card ">
                            <img src="frontend/images/SpecialOfferCardIconWhite.svg" alt="Special Offers Card Icon">
                            <div class="card-body">
                                <h5 class="card-title px-3"><span class="SuggestionsFaV float-start"><i class="fa-solid fa-heart"></i></span> Program 2
                                    <span class="SuggestionsAddToCart  float-end"><i class="fa-solid fa-cart-shopping"></i></span>
                                </h5>

                                <p>UI UX Design Fundemantals</p>
                                <a href="CourseDetailes.html"><button type="button" class="btn btn-outline-light">Course Detail</button></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 p-2">
                        <div class="card ">
                            <img src="frontend/images/SpecialOfferCardIconWhite.svg" alt="Special Offers Card Icon">
                            <div class="card-body">
                                <h5 class="card-title px-3"><span class="SuggestionsFaV float-start"><i class="fa-solid fa-heart"></i></span> Program 1
                                    <span class="SuggestionsAddToCart  float-end"><i class="fa-solid fa-cart-shopping"></i></span>
                                </h5>

                                <p>UI UX Design Fundemantals</p>
                                <a href="CourseDetailes.html"><button type="button" class="btn btn-outline-light">Course Detail</button></a>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </section>
    </div>
</section>
<!--End Suggestions-->
@endsection