@extends('frontend.layouts.master')
@section('auth_content')
<!--Get Started-->
<section class="GetStartedPage py-5 px-md-3">
    <div class="container-fluid">
        <div class="GreyTitle mb-2">
            Get Started
        </div>
        <div class="VideoPart mb-5">
            <h3 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing
                Elitr, Sed Diam
            </h3>
            <h6 style="color: #939597 ;" class="mb-3">Lorem Ipsum Dolor Sit Amet, Consetetur
                Sadipscing Elitr,
                Sed
                Diam Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam
                Voluptua. At Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita Kasd
                Gubergren, No Sea Takimata Lorem Ipsum</h6>
            <div class="iframeContainer">
                <iframe src="https://player.vimeo.com/video/253989945" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
            </div>
        </div>

        <div class="VideoPart mb-5">

            <h3 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing
                Elitr, Sed Diam
            </h3>
            <h6 style="color: #939597 ;" class="mb-3">Lorem Ipsum Dolor Sit Amet, Consetetur
                Sadipscing Elitr,
                Sed
                Diam Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam
                Voluptua. At Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita Kasd
                Gubergren, No Sea Takimata Lorem Ipsum</h6>
            <div class="iframeContainer">
                <iframe src="https://player.vimeo.com/video/253989945" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
            </div>
        </div>
        <button type="button" class="GetStartedBtn btn btn-primary mb-5 w-50 mx-auto d-flex justify-content-center"><b>Get
                Started </b> </button>

        <!--Leave A COmment-->
        <form>
            <div class="row mt-3">

                <div class="col-12 px-3 mb-4">
                    <label for="Comment" class="form-label w-100" style="color: #939597;font-size: 20px;"><b>Add a Comment <span class="float-end">423</span></b> </label>

                    <textarea name="Comment" id="Comment" class="form-control p-5" cols="30" rows="10" required placeholder="Comment"></textarea>
                </div>

            </div>
            <button type="submit" class=" GetStartedBtn btn btn-primary float-end"><b>Submit Commment
                </b>
            </button>
        </form>
        <br>
        <!--Comment section-->
        <div class="row  d-flex justify-content-center align-items-center  mt-5">
            <div class="col-md-12">
                <div class="card border-0">
                    <div class="p-3">
                        <div class="GreyTitle mb-2">
                            Reviews
                        </div>
                    </div>
                    <div class="CommentCards">
                        <div class="UserComment">
                            <div class="card mb-3 p-3">
                                <div class="row g-0 justify-content-center align-items-center">
                                    <div class="col-2 text-center">
                                        <img src="frontend/images/CommentImage.png" class="img-fluid rounded-start w-75" alt="Comment Image">
                                    </div>
                                    <div class="col-10">
                                        <div class="card-body pe-0">
                                            <p class="card-title UserCommentName">User Name
                                                <span class="CommentDate ms-3">21/02/2022</span>
                                            </p>

                                            <p class="card-text stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                                <span>(5.0)</span>
                                            </p>
                                            <p class="card-text CommentContent">Lorem Ipsum
                                                Dolor
                                                Sit Amet, Consetetur Sadipscing Elitr, Sed Diam
                                                Nonumy Eirmod Tempor Invidunt Ut Labore Et
                                                Dolore
                                                Magna Aliquyam Erat, Sed Diam Voluptua. At Vero
                                                Eos
                                                Et Accusam Et Justo Duo Dolores Et Ea Rebum.
                                                Stet
                                                Clita Kasd Gubergren, No Sea Takimata</p>
                                            <div class="card-buttons">
                                                <button type="button" class="btn btn-primary LikeBtn me-3">
                                                    <i class="fa-solid fa-thumbs-up me-1"></i>
                                                    34
                                                </button>
                                                <button type="button" id="replyOne" class="btn btn-primary ReplyBtn">
                                                    Reply
                                                </button>
                                            </div>

                                        </div>
                                    </div>
                                    <!--Reply Form-->
                                    <form id="ReplyFormOne">
                                        <div class="row mt-3 ps-5">

                                            <div class="col-12 px-3 mb-4">
                                                <label for="Comment" class="form-label w-100" style="color: #939597;font-size: 20px;"><b>Reply <span class="float-end">1</span></b> </label>

                                                <textarea name="Comment" id="Comment" class="form-control p-5" cols="30" rows="10" required placeholder="Comment"></textarea>
                                            </div>

                                        </div>
                                        <button type="submit" class=" GetStartedBtn btn btn-primary float-end"><b>Submit Commment
                                            </b>
                                        </button>
                                    </form>
                                </div>

                                <!--Reply To a comment-->
                                <div class="ReplyComment">
                                    <div class="card mb-3 p-3  float-end">
                                        <div class="row g-0 justify-content-center align-items-center">
                                            <div class="col-2 text-center">
                                                <img src="frontend/images/CommentImage.png" class="img-fluid rounded-start w-75" alt="Comment Image">
                                            </div>
                                            <div class="col-10">
                                                <div class="card-body pe-0">
                                                    <p class="card-title UserCommentName">User
                                                        Name
                                                        <span class="CommentDate ms-3">21/02/2022</span>
                                                    </p>

                                                    <p class="card-text stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                                        <span>(5.0)</span>
                                                    </p>
                                                    <p class="card-text CommentContent">Lorem
                                                        Ipsum
                                                        Dolor Sit Amet, Consetetur Sadipscing
                                                        Elitr,
                                                        Sed Diam Nonumy Eirmod Tempor Invidunt
                                                        Ut
                                                        Labore Et Dolore Magna Aliquyam Erat,
                                                        Sed
                                                        Diam Voluptua. At Vero Eos Et Accusam Et
                                                        Justo Duo Dolores Et Ea Rebum. Stet
                                                        Clita
                                                        Kasd Gubergren, No Sea Takimata</p>
                                                    <div class="card-buttons">
                                                        <button type="button" class="btn btn-primary LikeBtn me-3">
                                                            <i class="fa-solid fa-thumbs-up me-1"></i>
                                                            34
                                                        </button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
@endsection