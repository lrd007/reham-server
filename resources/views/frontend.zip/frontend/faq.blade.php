@extends('frontend.layouts.master')
@auth
@section('auth_content')
@endauth

@guest
@section('content')
@endguest
<!--FAQs Body-->
<Section class="FAQsBody  py-5 my-5" id="FAQsBody">

    <div class="container-fluid">
        <div class="GreyTitle">
            {{ __('words.FAQs') }}
        </div>
        <!--Accordion-->
        <div class="accordion" id="accordionPanelsStayOpenExample">
            @foreach($faqs as $faq)
            <div class="accordion-item mb-4">
                <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse{{$loop->index}}" aria-expanded="true" aria-controls="panelsStayOpen-collapse{{$loop->index}}">
                    {{ $faq->{ 'question'. withLocalization() } }}
                    </button>
                </h2>
                <div id="panelsStayOpen-collapse{{$loop->index}}" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
                    <div class="accordion-body">
                    {!! $faq->{ 'answer'. withLocalization() } !!}
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</Section>

<!--End FAQ Body-->
@endsection
