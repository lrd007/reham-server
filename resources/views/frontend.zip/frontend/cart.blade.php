@extends('frontend.layouts.master')
@section('auth_content')
<div class="mt-5">
        @if (count($cart_item) > 0)
            <!--Login Body-->
            <div class="row d-flex">
                <div class="col-md-8">
                    <div class="row">
                        @foreach ($cart_item as $key => $item)
                            @php
                                $amount = 0;
                                $amount += $item->courseFees()->pluck('sale_fee')->first();
                                $course_name = $item->name_en;
                                $description = $item->description_en;
                                if(Config::get('app.locale') =='ar'){
                                    $course_name = $item->name_ar;
                                    $description = $item->description_ar;
                                }
                            @endphp
                            <div class="col-md-6 m-0 mt-2" >
                                <div class="card" style="border-radius:30px; padding:20px">
                                    <div style="display: flex; justify-content: space-between;" >
                                        <p><strong>{{ $key + 1 }}.</strong></p>
                                        <a href="{{ route('remove_cart', ['program_id' => $item->id]) }}"><i class="fa fa-times" aria-hidden="true" style="margin-right: 20px"></i></a>
                                    </div>
                                    <div style="display: flex; align-items: baseline;">
                                        <p><strong>{{ $course_name }}</strong></p>
                                        <img src="{{asset('/assets/images/star.svg')}}" alt="" style="margin-left:20px">
                                        <img src="{{asset('/assets/images/star.svg')}}" alt="">
                                        <img src="{{asset('/assets/images/star.svg')}}" alt="">
                                        <img src="{{asset('/assets/images/star.svg')}}" alt="">
                                        <img src="{{asset('/assets/images/star.svg')}}" alt="">
                                           </div>
                                    <p>{{$amount}} {{ __('words.KD') }}</p>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card" style="border-radius:30px; padding:20px">
                        <form action="{{url('/payment-myfatoorah')}}" method="post">
                            @csrf
                            <table class="table">
                                @php
                                    $total_amount = 0;
                                @endphp
                                @foreach ($cart_item as $key => $item)
                                    @php
                                        $amount = 0;
                                        $amount += $item->courseFees()->pluck('sale_fee')->first();
                                        $total_amount += $amount;
                                    @endphp
                                    <input type="hidden" name="program_id[{{$key}}]" value="{{$item->programs_id}}">
                                @endforeach
                                <tr>
                                    <th colspan="2">{{ __('words.Item Quantity') }}</th>
                                    <th colspan="1">{{$key + 1}}</th>
                                </tr>
                                <tr>
                                    <th colspan="2">{{ __('words.Subtotal') }} </th>
                                    <th colspan="1">{{$total_amount}}</th>
                                </tr>
                                <tr>
                                    <th colspan="2">{{ __('words.Discounted Amount') }}</th>
                                    <th colspan="1">0</th>
                                </tr>
                                <tr>
                                    <th colspan="2">{{ __('words.Total') }} </th>
                                    <th colspan="1">{{$total_amount}} </th>
                                </tr>
                                <tr style="text-align: center;">
                                    <th colspan="3" >
                                        <input type="hidden" name="amount" value="{{$total_amount}}">
                                        <button class="btn btn-info" style="width: 90%;">{{ __('words.Pay Now') }}</button>
                                    </th>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        @else
            <Section class="CartBody py-3 text-center " id="CartBody">
                <div class="container-fluid">
                    <div class="row ">
                        <div class="col-12  d-flex  justify-content-center">
                            <div
                                class=" CartWhite RightBottomCorner d-flex flex-column justify-content-center align-content-center  ">
                                <i class="fa-solid fa-cart-shopping mt-5"></i>
                                <br>
                                <h2 class="mt-2 text-center mb-5"><b>{{ __('words.Your cart is empty') }}</b></h2>

                                <button type="submit" class="btn btn-primary  position-relative mx-auto ">{{ __('words.Shop Now') }}</button>

                            </div>
                        </div>
                    </div>
                </div>
            </Section>
        @endif
        <!--End Login Body-->
    </div>
@endsection
