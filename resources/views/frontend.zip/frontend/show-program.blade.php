@extends('frontend.layouts.master')
@section('auth_content')
<!--Course One-->
<section class="Courses py-5 px-md-3">
    <div class="container-fluid">
        @if(isset($program_data))
            @php
                $program_name = $title;
            @endphp

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="{{route('all_programs')}}">{{ __('words.My Programs') }}</a></li>
                    <li class="breadcrumb-item active">{{$program_name}}</li>
                </ol>
            </nav>

                @php
                    $course_name = $program_data->name_en;
                    $description_1 = $program_data->description_en;
                    $description_2 = $program_data->description_en_2;
                    if(Config::get('app.locale')=='ar'){
                        $course_name = $program_data->name_ar;
                        $description_1 = $program_data->description_ar;
                        $description_2 = $program_data->description_ar_2;
                    }
                @endphp
                <div class="GreyTitle mb-2">
                    {{$course_name}}
                    -

                </div>
                <h3 style="color: #939597 ;">{!!$description_1!!}</h3>
                <h6 style="color: #939597 ;">{!!$description_2!!}</h6>


                @foreach ($program_data->chapters as $chapter)
                    @php
                        $chapter_name = $chapter->name_en;
                        $description = $chapter->description_en;
                        if(Config::get('app.locale')=='ar'){
                            $chapter_name = $chapter->name_ar;
                            $description = $chapter->description_ar;
                        }
                    @endphp
                    <div class="row mb-3 mt-5">
                    <div class="col-md-6 col-12 d-flex flex-column  ChapterDescription">
                        <a href="{{route('chapter-details',['program_id' => $program_data->id , 'course_id' => $chapter->id ])}}">
                            <h2 class="ChapterNumber text-start w-100">
                                {{$chapter_name}}
                                <small> <sub>({{ $chapter->lessons->count() }} {{ __('words.Lesson') }})</sub></small>
                            </h2>
                        </a>
                        <div style="    font-weight: bold;">{!!$description!!}</div>
                    </div>
                    <div class="col-md-3 col-6 ChapterDetails d-flex align-items-center">
                        <!-- To DO -->
                         <p class="mb-0">
                            {{ __('words.completed') }}
                            <br>
                            <span class="ChapterComplitationPercentage">
                                {{ auth()->user()->subscriber->CourseComplete($program_data->id,$chapter->id ) }} %
                            </span>
                        </p>
                    </div>
                    <div class="col-md-3 col-6 ChapterDetails d-flex align-items-center">
                        <p class="mb-0">
                             {{ __('words.Duration') }}
                            <br>
                            <span class="ChapterDuration">{{$chapter->TimeOfLessons() ?? 0}} {{ __('words.Min') }}</span>
                        </p>
                    </div>
                    </div>
                @endforeach

        @else
            <h3>No Program Deatils</h3>
        @endisset
    </div>
</section>
@endsection
