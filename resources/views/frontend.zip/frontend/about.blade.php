@extends('frontend.layouts.master')
@auth
@section('auth_content')
@endauth

@guest
@section('content')
@endguest

<!--Login Body-->
<Section class="AboutBody  " id="AboutBody">

  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-12">
        <div class="UploadImage d-flex justify-content-center align-items-center  p-0">
          <img src="frontend/images/CarouselImage.png" alt="" class="w-100 RightTopCorner">
        </div>
      </div>
      <div class="col-lg-6 col-12 AboutText">
        <h4><b>{{ __('words.About Us') }}</b></h4>
        <p>{{$description_en}}</p>
      </div>
    </div>
  </div>
</Section>

<!--End Login Body-->
@endsection
