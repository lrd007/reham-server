@extends('frontend.layouts.master')
@auth
@section('auth_content')
@endauth

@guest
@section('content')
@endguest
<!--CartFull Body-->
<Section class="CartFullBody  my-5" id="CartFullBody">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-3 border-0">
                    <div class="row g-0">
                        <div class="col-2 d-flex justify-content-center align-items-center title mb-0" style="font-size: 80px;">
                            <i class="fa-solid fa-cart-shopping"></i>
                        </div>
                        <div class="col-10">
                            <div class="card-body">
                                <h5 class="card-title GreyTitle">Shopping Cart</h5>
                                <h5 class="card-text" style="color: #939597;">2 items</h5>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row CartItems">
                    <div class="col-md-6">
                        <div class="card px-3 py-4 RightTopCorner">
                            <img src="frontend/images/item.webp" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <p class="card-title">Courses Name <span class="float-end">
                                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></p>
                                <p class="card-text">Lorem Ipsum Dolor Sit Amet, Consetetur</p>
                                <h6 class="card-text"><s class="me-4"> $50.00 </s> <span>$29.00 </span>
                                </h6>

                                <a href="CourseDetailes.html" class="btn btn-primary">Go to course</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card px-3 py-4 RightTopCorner">
                            <img src="frontend/images/item.webp" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <p class="card-title">Courses Name <span class="float-end"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></p>
                                <p class="card-text">Lorem Ipsum Dolor Sit Amet, Consetetur</p>
                                <h6 class="card-text"><s class="me-4"> $50.00 </s> <span>$29.00 </span>
                                </h6>

                                <a href="CourseDetailes.html" class="btn btn-primary">Go to course</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="OrderSummary p-5">
                    <div>
                        <h3>Order Summary</h3>
                        <p class="ItemQuantity">Item Quantity <span class="float-end"><b>2</b></span>
                        </p>
                        <div class="OrderCoupon pt-3">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control " placeholder="Coupon Code" aria-label="Coupon Code" aria-describedby="button-addon2">
                                <button class="btn btn-primary w-100 mt-2" type="button" id="button-addon2">Apply</button>
                            </div>

                            <p class="ItemQuantity">Subtotal <span class="float-end"> 100 KD</span></p>
                            <p class="ItemQuantity">Discounted amount <span class="float-end">0
                                    KD</span></p>

                        </div>
                    </div>
                    <div class="OrderTotalAndCheckOut">
                        <form action="">
                            <p class="OrderTotal mb-4 w-100">Total: <span class="float-end">$60</span>
                            </p>
                            <div class="form-check mt-3">
                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                <label class="form-check-label" for="exampleRadios1">
                                    <p>k-net</p>
                                </label>
                            </div>
                            <div class="form-check mt-2">
                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2" required>
                                <label class="form-check-label" for="exampleRadios2">
                                    <p>Credit card</p>
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary px-5 mt-4">Pay Now </button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>
</Section>

<!--End CartFull Body-->
@endsection