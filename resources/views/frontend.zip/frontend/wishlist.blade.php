@extends('frontend.layouts.master')
@section('auth_content')
<!--whishlist-->
<section class="WhishlistSection py-5 px-md-3">
    <div class="container-fluid">
        <div class="GreyTitle mb-5">
            {{__('words.Whishlist')}}
        </div>
        <!--Whish List-->
        <section class="WhishList specialOffer mb-5" id="WhishList">
            <div class="row">
                <!-- Cards-->
                <div class="card-group WhishListCardGroup">
                    @foreach($items as $course)
                    <div class="col-md-4 p-2">
                        <div class="card ">
                            <img src="frontend/images/SpecialOfferCardIconWhite.svg" alt="Special Offers Card Icon">
                            <div class="card-body">
                                <h5 class="card-title px-3"><span class="WhishListTrash float-start"><i class="fa-solid fa-trash  "></i></span> {{ $course->{ 'name'. withLocalization() } }}
                                    <span class="WhishListAddToCart  float-end"><i class="fa-solid fa-cart-shopping"></i></span>
                                </h5>

                                <p>{!! $course->{ 'description'. withLocalization() } !!}</p>
                                <a href="CourseDetailes.html"><button type="button" class="btn btn-outline-light">{{ __('words.Course Detail') }}</button></a>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <h1 class="NoWhishlist">There's no Program</h1>
            </div>
        </section>
        <!--End Whish List-->
    </div>
</section>
<!--End whishlist-->
@endsection
