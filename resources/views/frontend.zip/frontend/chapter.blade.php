@extends('frontend.layouts.master')
@section('auth_content')
<!--Chapter One-->
<section class="Chapter py-5 px-md-3">
    <div class="container-fluid">
        <nav class="BreadCrumbNavBar">

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="#">My Programs</a></li>
                <li class="breadcrumb-item"><a href="#">Course 1</a></li>
                <li class="breadcrumb-item active" aria-current="page">Chapter 1</li>
            </ol>
        </nav>
        <div class="GreyTitle mb-2">
            Chapter 1
        </div>
        <h3 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing
            Elitr, Sed Diam
        </h3>
        <div class="container-fluid">

            <div class="ChaptersDiv ">
                <div class="row mt-5">
                    <div class="col-sm-8  mb-3 d-flex flex-column align-self-center">
                        <div class="row mb-3">
                            <div class="col-md-4 col-12 d-flex align-items-center">
                                <h2 class="lessonNumber">Lesson 1</h2>
                            </div>
                            <div class="col-md-4 col-6 LessonDetails d-flex align-items-center">
                                <p class="mb-0">
                                    completed
                                    <br>
                                    <span class="LessonComplitationPercentage">70%</span>
                                </p>
                            </div>
                            <div class="col-md-4 col-6 LessonDetails d-flex align-items-center">
                                <p class="mb-0">
                                    duration
                                    <br>
                                    <span class="LessonDuration">15Min</span>
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 LessonDescription">
                                Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr,
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="row">
                            <div class="col-10 LessonVid notAvailable">
                                <img src="frontend/images/poster.jpg" alt="" class="w-100">
                                <div class="LessonVidText">
                                    <p>Not Availabel till :
                                        <br>
                                        31/2/2022
                                    </p>
                                </div>
                            </div>
                            <div class="col-2 d-flex align-self-center">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-sm-8  mb-3 d-flex flex-column align-self-center">
                        <div class="row mb-3">
                            <div class="col-md-4 col-12 d-flex align-items-center">
                                <h2 class="lessonNumber">Lesson 2</h2>
                            </div>
                            <div class="col-md-4 col-6 LessonDetails d-flex align-items-center">
                                <p class="mb-0">
                                    completed
                                    <br>
                                    <span class="LessonComplitationPercentage">30%</span>
                                </p>
                            </div>
                            <div class="col-md-4 col-6 LessonDetails d-flex align-items-center">
                                <p class="mb-0">
                                    duration
                                    <br>
                                    <span class="LessonDuration">20Min</span>
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 LessonDescription">
                                Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr,
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="row">
                            <div class="col-10 LessonVid Available">
                                <div class="iframeContainerSmall w-100">
                                    <iframe src="https://player.vimeo.com/video/253989945" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
                                </div>
                            </div>
                            <div class="col-2 d-flex align-self-center">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection