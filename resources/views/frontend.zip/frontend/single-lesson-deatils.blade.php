@extends('frontend.layouts.master')
@section('auth_content')

    <!--Lessons-->
    <section class="Lesson py-5 px-md-3" id="">
        <div class="container-fluid">
            <nav
                style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);"
                aria-label="breadcrumb">
                <ol class="breadcrumb">
                    @php
                        $program_name = $program_data->name_en;
                        $course_name = $course_data->name_en;
                        $chapter_name = $chapter_data->name_en;
                        $lesson_name = $lesson_data->name_en;
                        $lesson_description = $lesson_data->description_en;
                        if(Config::get('app.locale') == 'ar'){
                            $program_name = $program_data->name_ar;
                            $course_name = $course_data->name_ar;
                            $chapter_name = $chapter_data->name_ar;
                            $lesson_name = $lesson_data->name_ar;
                            $lesson_description = $lesson_data->description_ar;
                        }
                    @endphp

                    <li class="breadcrumb-item">
                        <a href="#"><i class="fa-solid fa-house"></i></a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="{{route('all_programs')}}">My Programs</a></li>
                    <li class="breadcrumb-item">
                        <a href="{{route('single-program',['program_id' => $program_data->id])}}">{{$program_name}}</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="{{route('chapter-details',['program_id' => $program_data->id , 'course_id' => $course_data->id ])}}">{{$course_name}}</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="{{route('lesson-details',['program_id' => $program_data->id , 'course_id' => $course_data->id, 'chapter_id' =>  $chapter_data->id])}}">{{$chapter_name}}</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">{{$lesson_name}}</li>

                </ol>
            </nav>
            <h3 style="color: #939597 ;">{{$lesson_name}}</h3>
            <p class="ts-desc-md mb-06">
            <p>
                <span style="color: rgb(0, 0, 0);">{!!$lesson_description!!} </span>
            </p>
            </p>

            <div class="iframeContainer">
                @if(!is_null($lesson_data->vimeo_embeded_code) || strlen($lesson_data->vimeo_embeded_code) > 5)
                    <iframe src="{{ $lesson_data->vimeo_embeded_code }}" webkitallowfullscreen mozallowfullscreen
                            allowfullscreen title="{{$lesson_name}}"></iframe>
                @elseif(isset($lesson_data->vimeo_url))
                    <iframe src="{{ str_replace('vimeo.com/','player.vimeo.com/video/',$lesson_data->vimeo_url) }}"
                            webkitallowfullscreen mozallowfullscreen allowfullscreen title="{{$lesson_name}}"></iframe>
                @else

                @endif
            </div>
            <form>
                <div class="row my-4">
                    @if(isset($previous_lesson))
                        <div class="col-md-3 col-6">
                            <a href="{{ $previous_lesson }}">
                                <button type="button" class="btn btn-primary px-0 w-100 mb-3">
                                    <b>Previous Lesson</b>
                                </button>
                            </a>
                        </div>
                    @else
                        <div class="col-md-4 col-6">
                            <a>
                                <button type="button" class="btn btn-default px-0 w-100 mb-3 disabled-button" disabled>
                                    <b>Previous Lesson</b>
                                </button>
                            </a>
                        </div>
                    @endif

                    @if(isset($next_lesson))
                        <div class="col-md-4 col-6">
                            <a href="{{ $next_lesson }}">
                                <button type="button" class="btn btn-primary px-0 w-100 mb-3">
                                    <b>Next Lesson</b>
                                </button>
                            </a>
                        </div>
                    @endif

                    <div class="col-md-4 col-6 mt-3">
                        @php
                            $checked = ($lesson_data->is_completed) ? 'checked="checked"' :  '';
                        @endphp

                        <input class="form-check-input" type="checkbox" value="" {{$checked}} id="flexCheckDefault">
                        <inpu type="hidden" class="flexCheckDefault" data-id="{{ $lesson_data->id }}"/>
                        <label for="flexCheckDefault" style="color: #EA8BB9;"><b class="result">
                                Mark as Complete </b></label>

                    </div>


                    <!--
                   <div class="col-md-3 col-6">
                       <button type="link" class="btn btn-primary  px-0 w-100  mb-3">
                           <a href="Quiz.html" style="color: white;">
                               <b>Attemp Quiz </b>
                           </a>
                       </button>
                   </div>
                   <div class="col-md-3 col-6">
                       <button type="link" class="btn btn-primary  px-0 w-100  mb-3">
                           <a href="AddingStory.html" style="color: white;">
                               <b>Upload Story</b>
                           </a>
                       </button>
                   </div>
                   <div class="col-md-3 col-6">
                       <button type="button" class="btn btn-primary  px-0 w-100  mb-3">
                           <b>Related Link </b>
                       </button>
                   </div>
                    -->
                </div>


                <div class="GreyTitle mb-3">
                    {{ __('words.Course Description') }}
                </div>
                <h6 style="color: #939597 ;">{!!$lesson_description!!}</h6>
                <div class="align-items-center mb-11 hstack gap-5 minBreakpoint-xs">
                    @if($lesson_data->document)
                        <a class="ts-desc-md text-primary-07 text-decoration-none fw-bold"
                           href="/uploads/files/lesson/{{ $lesson_data->document }}"
                           download="">
                            Download pdf
                        </a>
                    @endif
                </div>
            </form>

            <form class="ts-review-post my-4" method="post" action="{{ route('add-lesson-comment',$lesson_data->id) }}">
                {{ csrf_field() }}
                <div class="justify-content-between mb-06 hstack minBreakpoint-xs">
                    <div class="row">

                        <div class="col-11">
                            <h2 class="heading-1 form-label" for="exampleForm.ControlTextarea1">
                                {{ __('words.Leave your comment') }}
                            </h2>
                        </div>
                        <div class="col-1"><h1>💬</h1></div>

                        <textarea rows="4"  placeholder="{{ __('words.Write your comment') }}" name="comment" id="exampleForm.ControlTextarea1"
                                  class="form-control textarea-2">

                        </textarea>
                    </div>
                </div>

                <div class="text-end mt-2">
                    <button type="submit" class="btn btn--border-white btn-lg px-5 w-auto  btn btn-primary-01">
                        {{ __('words.Submit Comment') }}
                    </button>
                </div>
            </form>

            <div class="justify-content-between mb-09 ms-lg-4  hstack minBreakpoint-xs">
                <div class="row">
                    <div class="col-10">
                        <h1 class="text-gray-05 ">{{ __('words.Reviews') }}</h1>
                    </div>
                    <div class="col-2">
                        <h1 class="text-gray-05 ">{{ $lesson_data->comments->count() }}</h1>
                    </div>
                </div>

            </div>

            <div class="vstack gap-4 minBreakpoint-xs">
                @foreach($lesson_data->comments as $comment)
                <article class="ts-review my-3">
                    <div class="ts-review__inner">
                        <header class="ts-review__header  d-flex align-items-center">
                            <img class="ts-review__user-img"
                                 src="{{ isset($comment->user->subscriber->image) ? asset($comment->user->subscriber->image) :  asset('assets/icons/profile-picture.svg') }}" alt="...">
                        </header>
                        <div class="ts-review__main">
                            <div class="align-items-center mb-03 hstack gap-3 minBreakpoint-xs"><h6
                                    class="ts-review__name text-gray-05 mb-0">
                                    {{ $comment->user->subscriber->full_name ?? 'Unknown' }}
                                </h6>
                                <p class="ts-review__date text-nowrap text-gray-05 fw-bold mb-0">
                                    {{ \Carbon\Carbon::parse($comment->created_at)->diffForHumans() }}
                                </p></div>
                            <p class="ts-review__message text-gray-05 mb-03">
                                {{ $comment->comment }}
                            </p>

                            <!-- TO DO -->


                            <div class="hstack gap-5 minBreakpoint-xs">
                                <div class="ts-review__likes align-items-center hstack gap-3 minBreakpoint-xs">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <h5 class=" mb-0 text-gray-05 liked liked-{{ $comment->id  }} d-inline-block" style="display: inline;">{{ $comment->like ? $comment->like : 0 }}</h5>
                                            <div class="like" data-id="{{$comment->id}}">
                                                <img class="ts-review__likes-thumb" width="31" src="/assets/icons/Icon-Like.svg" alt="...">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <button class="btn btn-primary-07 replayB replay" data-id="{{ $comment->id }}">Reply</button>
                                        </div>

                                        <div class="col-md-8"></div>
                                    </div>

                                </div>
                                <form class="ts-review-post my-4 d-hide replay-Form-{{ $comment->id }}" method="post"  action="{{ route('add-lesson-comment',['lesson_id'=>$lesson_data->id,'comment_id'=>$comment->id]) }}">
                                    {{ csrf_field() }}
                                    <div class="justify-content-between mb-06 hstack minBreakpoint-xs">
                                        <div class="row">

                                            <div class="col-11">
                                                <h2 class="heading-1 form-label" for="exampleForm.ControlTextarea1">
                                                    {{ __('words.Leave your comment') }}
                                                </h2>
                                            </div>
                                            <div class="col-1"><h4>👀</h4></div>
                                            <textarea rows="4"  placeholder="{{ __('words.Write your comment') }}" name="comment" id="exampleForm.ControlTextarea1" class="form-control textarea-2"></textarea>
                                        </div>
                                    </div>

                                    <div class="text-end mt-2">
                                        <button type="submit" class="btn btn--border-white btn-lg px-5 w-auto  btn btn-primary-01">
                                            {{ __('words.Submit Comment') }}
                                        </button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                    <!-- Replays-->
                    @foreach($comment->allChildren as $replay)


                    <ul class="ts-review__children">
                        <li class="ts-review__children-item">
                            <header class="ts-review__header  d-flex align-items-center"><img
                                    class="ts-review__user-img" src="{{ isset($replay->user->subscriber->image) ? asset($replay->user->subscriber->image) :  asset('assets/icons/profile-picture.svg') }}" alt="...">
                            </header>
                            <div class="ts-review__main ">
                                <div class="align-items-center mb-03  hstack gap-3 minBreakpoint-xs"><h6
                                        class="ts-review__name text-gray-05 mb-0">{{ $replay->user->subscriber->full_name ?? 'Unknown' }}</h6>
                                    <p class="ts-review__date text-nowrap text-gray-05 fw-bold mb-0"> {{ \Carbon\Carbon::parse($replay->created_at)->diffForHumans() }}</p>
                                </div>
                                <p class="ts-review__message text-gray-05 mb-03">{{ $replay->comment }}</p>
                                <div class="hstack gap-5 minBreakpoint-xs">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <h5 class=" mb-0 text-gray-05 liked liked-{{ $replay->id  }}" style="    display: inline;">{{ $replay->like ? $replay->like : 0 }}</h5>
                                            <div class="like" data-id="{{$replay->id}}">
                                                <img class="ts-review__likes-thumb" width="31" src="/assets/icons/Icon-Like.svg" alt="like">
                                            </div>
                                        </div>
                                        <div class="col-md-2">

                                        </div>

                                        <div class="col-md-8"></div>
                                    </div>


                                </div>
                            </div>
                        </li>
                    </ul>
                    @endforeach
                    <!-- Replays-->
                </article>
                @endforeach

            </div>

        </div>
    </section>
    <style>
        .vp-preview, #vp-preview {
            border-radius: 50px !important;
        }
    </style>
    <script>
        $(function(){
            $('#vp-preview').css('border-radius',50);
        })
    </script>
@endsection
