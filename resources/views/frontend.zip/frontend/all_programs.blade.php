@extends('frontend.layouts.master')
@section('auth_content')
    <!--ALl Programs-->
    <section class="Courses py-5 px-md-3" id="">
        <div class="container-fluid">
            <div class="GreyTitle">
                {{ __('words.My Programs') }}
            </div>
            @auth()

                <section class="specialOffer  mb-5" id="specialOffer">
                    <div class="row">
                        <!--Special Offer Cards-->
                        <div class="card-group">

                            @foreach ($my_programs as $program)
                                    @php
                                        $program_name = $program ? $program->name_en : NULL;
                                        if(Config::get('app.locale')=='ar'){
                                            $program_name = $program ? $program->name_ar : NULL;
                                        }
                                    @endphp

                                    @if($program_name != NULL)
                                        <div class="col-md-4 p-2 text-xl-center">
                                            <div class="card">
                                                <img src="frontend/images/SpecialOfferCardIconWhite.svg"
                                                     alt="Special Offers Card Icon">
                                                <div class="card-body">
                                                    <h5 class="card-title">{{$program_name}}</h5>

                                                    <p style="color:white;">
                                                        <br>
                                                       {{-- <span class="ProgramComplitationPercentage">70% complete</span>--}}
                                                    </p>
                                                    <a href="{{route('single-program',['program_id' => $program->id])}}">
                                                        <button type="button" class="btn btn-outline-light selectCourse"
                                                        style="border: 2px solid #fff; transition: color,background-color,.3s ease-in-out; border-radius: 50rem; color: #fff; font-size: clamp(1.3rem,4vw,1.5rem); font-weight: 700; max-width: 260px; padding: 7px 20px 8px; width: 100%;    background: initial;">{{ __('words.Start lesson') }}</button>
                                                    </a>

                                                </div>
                                            </div>
                                        </div>
                                    @endif
                            @endforeach

                        </div>
                    </div>
                </section>

            @endauth
        </div>
    </section>
    <!--End All Programs-->

    <script>
        function copyToClipboard(url) {
            var TempText = document.createElement("input");
            TempText.value = url;
            document.body.appendChild(TempText);
            TempText.select();
            document.execCommand("copy");
            document.body.removeChild(TempText);
        }
    </script>
@endsection
