@extends('frontend.layouts.master')
@section('auth_content')
<!--Lessons-->
<section class="Lesson py-5 px-md-3" id="">
    <div class="container-fluid">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb">
                @php
                $program_name = $program_data->name_en;
                $course_name = $course_data->name_en;
                $chapter_name = $chapter_data->name_en;
                $chapter_description = $chapter_data->description_en;
                if(Config::get('app.locale')=='ar'){
                $program_name = $program_data->name_ar;
                $course_name = $course_data->name_ar;
                $chapter_name = $chapter_data->name_ar;
                $chapter_description = $chapter_data->description_ar;
                }
                @endphp
                <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house"></i></a></li>
                <li class="breadcrumb-item"><a href="{{route('all_programs')}}">My Programs</a></li>
                <li class="breadcrumb-item"><a href="{{route('single-program',['program_id' => $program_data->id])}}">{{$program_name}}</a></li>
                <li class="breadcrumb-item" aria-current="page"><a href="{{route('chapter-details',['program_id' => $program_data->id , 'course_id' => $course_data->id ])}}">{{$course_name}}</a></li>
                <li class="breadcrumb-item active" aria-current="page">{{$chapter_name}}</li>

            </ol>
        </nav>
        <div class="GreyTitle mb-2">
            {{$chapter_name}}
        </div>
        <h3 style="color: #939597 ;">{!!$chapter_description!!}</h3>

        <div class="container-fluid">

            <div class="ChaptersDiv">
                @php
                $user_id = auth()->user()->id;
                @endphp
                @foreach ($chapter_data->lessons as $lesson)
                @php
                $lesson_name = $lesson->name_en;
                $lesson_description = $lesson->description_en;
                $mark_as_read_check = Modules\Lesson\Entities\LessonCompletion::where('subscriber_id', $user_id)->where('lesson_id', $lesson->id)->first() == NULL ? '' : 'checked="checked"';
                if(Config::get('app.locale')=='ar'){
                $lesson_name = $lesson->name_ar;
                $lesson_description = $lesson->description_ar;
                }
                @endphp
                <div class="row mt-5">
                    <div class="col-sm-8 mb-3 d-flex flex-column align-self-center">
                        <div class="row mb-3">
                            <div class="col-md-10 col-12 d-flex align-items-center">
                                <a href="{{route('single-lesson-details',['program_id' => $program_data->id , 'course_id' => $course_data->id , 'chapter_id' => $chapter_data->id , 'lesson_id' => $lesson->id])}}">
                                    <h2 class="lessonNumber">{{$lesson_name}}</h2>
                                </a>
                            </div>
                            <div class="col-md-1 col-6 LessonDetails d-flex align-items-center">
                                {{-- <p class="mb-0">
                                            completed
                                            <br>
                                            <span class="LessonComplitationPercentage">70%</span>
                                        </p> --}}
                            </div>
                            <div class="col-md-1 col-6 LessonDetails d-flex align-items-center">
                                <p class="mb-0">
                                    Duration
                                    <br>
                                    <span class="LessonDuration">{{$lesson->duration ?? 0}} Min</span>
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 LessonDescription">
                                {!!$lesson_description!!}
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="row">
                            <!-- <div class="col-10 LessonVid notAvailable">
                                    <img src="{{url(uploads_images('lesson', null, true) . '/' . $lesson->thumb_image)}}" alt="" class="w-100">
                                    <div class="LessonVidText">
                                        <p>Not Availabel till :
                                            <br>
                                            31/2/2022
                                        </p>
                                    </div>
                                </div> -->

                            <!-- <form action="{{ route('lesson-mark-unmark', ['lesson_id' => $lesson->id]) }}" method="GET">
                                    @csrf -->
                            <div class="col-2 d-flex align-self-center" style="margin-left: 200px; margin-top: 10px;">
                                <!-- <input class="form-check-input" type="checkbox" value="" {{$mark_as_read_check}} id="flexCheckDefault" onclick="testFunction('{{ $lesson->id }}');"> -->
                                <!-- <button type="submit"> -->
                                <!-- <input class="form-check-input" type="checkbox" value="" {{$mark_as_read_check}} id="flexCheckDefault" > -->
                                <input type="checkbox" name="mark" onclick="lessonMarkUnmark({{$lesson->id}})" value="1" {{ old('mark', $mark_as_read_check) ? $mark_as_read_check : '' }} />
                                <!-- </button> -->
                            </div>
                            <!-- </form> -->
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        <!-- <div class="iframeContainer">
            <iframe src="https://player.vimeo.com/video/253989945" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
        </div>
        <form>
            <div class="row my-4">
                <div class="col-md-3 col-6">
                    <button type="button" class="btn btn-primary px-0 w-100 mb-3">
                        <b>Next Lesson</b>
                    </button>
                </div>
                <div class="col-md-3 col-6">
                    <button type="link" class="btn btn-primary  px-0 w-100  mb-3">
                        <a href="Quiz.html" style="color: white;">
                            <b>Attemp Quiz </b>
                        </a>
                    </button>
                </div>
                <div class="col-md-3 col-6">
                    <button type="link" class="btn btn-primary  px-0 w-100  mb-3">
                        <a href="AddingStory.html" style="color: white;">
                            <b>Upload Story</b>
                        </a>
                    </button>
                </div>
                <div class="col-md-3 col-6">
                    <button type="button" class="btn btn-primary  px-0 w-100  mb-3">
                        <b>Related Link </b>
                    </button>
                </div>
            </div>
            <div class="row mt-3 justify-content-end mb-5">
                <div class="col-md-3 col-12 float-end text-center">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                    <label for="flexCheckDefault" style="color: #EA8BB9;"><b> Mark as Complete</b></label>
                </div>
            </div>

            <div class="GreyTitle mb-3">
                Lesson Description
            </div>
            <h6 style="color: #939597 ;">{!!$chapter_description!!}</h6>
        </form> -->
    </div>
</section>

<script>
    function lessonMarkUnmark(id) {
        $.ajax({
            type: 'GET',
            url: '/lesson-mark-unmark/' + id,
            dataType: 'json',
            headers: {
                Accept: "application/json"
            },
            success: function(data) {
                console.log(data);
            }
        });
    }

    function testFunction(data) {
        console.log(data);
    }
</script>
@endsection