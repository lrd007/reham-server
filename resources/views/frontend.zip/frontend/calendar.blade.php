@extends('frontend.layouts.master')
@section('auth_content')
<section class="calendar px-md-3 py-5">

    <div id='wrap'>

        <div id='calendar'></div>

        <div style='clear:both'></div>
    </div>
</section>
<!--End Calendar-->
@endsection