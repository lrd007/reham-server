@extends('frontend.layouts.master')
@section('auth_content')
<!-- Stories-->
<section class="InspiringStoriesSection px-md-3 py-5">
    <div class="container-fluid">
        <div class="GreyTitle mb-4">
            Inspiring Stories
        </div>
        <p class="mb-4" style="font-size: 14px; color: #939597 ;">Lorem ipsum dolor sit amet,
            consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
            dolore
            magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores
            et
            ea rebum. Stet clita kasd</p>
        <form action="">
            <a href="AddingStory.html" class="UploadStoryLabel">Upload Your Story</a>

        </form>
        <div class="row mt-5">
            <div class="col-md-4 mb-5">
                <div class="card p-3 py-4 RightTopCorner">
                    <img src="frontend/images/Stories Image.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><b>Insipiring Stories</b></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consetetur sadipscing
                            elitr, sed diam nonumy eirmod tempor</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-5">
                <div class="card p-3 py-4 RightTopCorner">
                    <img src="frontend/images/Stories Image.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><b>Insipiring Stories</b></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consetetur sadipscing
                            elitr, sed diam nonumy eirmod tempor</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-5">
                <div class="card p-3 py-4 RightTopCorner">
                    <img src="frontend/images/Stories Image.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><b>Insipiring Stories</b></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consetetur sadipscing
                            elitr, sed diam nonumy eirmod tempor</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-5">
                <div class="card p-3 py-4 RightTopCorner">
                    <img src="frontend/images/Stories Image.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><b>Insipiring Stories</b></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consetetur sadipscing
                            elitr, sed diam nonumy eirmod tempor</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-5">
                <div class="card p-3 py-4 RightTopCorner">
                    <img src="frontend/images/Stories Image.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><b>Insipiring Stories</b></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consetetur sadipscing
                            elitr, sed diam nonumy eirmod tempor</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-5">
                <div class="card p-3 py-4 RightTopCorner">
                    <img src="frontend/images/Stories Image.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><b>Insipiring Stories</b></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consetetur sadipscing
                            elitr, sed diam nonumy eirmod tempor</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Stories-->
@endsection