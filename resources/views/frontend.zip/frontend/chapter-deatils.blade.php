@extends('frontend.layouts.master')
@section('auth_content')
<!--Chapter One-->
<section class="Chapter py-5 px-md-3">
    <div class="container-fluid">
        <nav class="BreadCrumbNavBar">
            <ol class="breadcrumb">
                @php
                    $program_name = $program_data->name_en;
                    $course_name = $course_data->name_en;
                    $course_description = $course_data->description_en;
                    if(Config::get('app.locale')=='ar'){
                        $program_name = $program_data->name_ar;
                        $course_name = $course_data->name_ar;
                        $course_description = $course_data->description_ar;
                    }
                @endphp
                <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('all_programs')}}">My Programs</a></li>
                <li class="breadcrumb-item"><a href="{{route('single-program',['program_id' => $program_data->id])}}">{{$program_name}}</a></li>
                <li class="breadcrumb-item active" aria-current="page">{{$course_name}}</li>
            </ol>
        </nav>
        <div class="GreyTitle mb-2">
            {{$course_name}}
        </div>
        <h3 style="color: #939597 ;">{!!$course_description!!}</h3>
        <div class="container-fluid">

            <div class="ChaptersDiv ">
                @foreach ($course_data->lessons as $chapter)
                    @php
                        $chapter_name = $chapter->name_en;
                        $chapter_description = $chapter->description_en;
                        if(Config::get('app.locale')=='ar'){
                            $chapter_name = $chapter->name_ar;
                            $chapter_description = $chapter->description_ar;
                        }
                    @endphp
                    <div class="row mt-5">

                        <div class="col-sm-9 mb-3 d-flex flex-column align-self-center">
                            <div class="row mb-3">
                                <div class="col-md-1 col-1 d-flex align-items-center">
                                    <form class="">
                                        <div class="mb-3 ">
                                            <div class="">

                                                <input role="button" data-lesson-id="60" type="checkbox"
                                                       @if($chapter->is_completed) checked @endif
                                                       id="default-checkbox" class="form-check-input" >
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div class="col-md-6 col-11 d-flex align-items-center">
                                    <a href="{{route('lesson-details',['program_id' => $program_data->id , 'course_id' => $course_data->id , 'chapter_id' => $chapter->id ])}}">
                                        <h2 class="lessonNumber">{{$chapter_name}}</h2>
                                    </a>
                                </div>
                                <div class="col-md-2 col-6 LessonDetails d-flex align-items-center">
                                    <!-- TO DO -->
                                     <p class="mb-0">
                                         @if($chapter->is_completed) {{__('words.completed')}} @else {{__('words.not completed')}} @endif
                                        <br>
                                        <span class="LessonComplitationPercentage">@if($chapter->is_completed) 100 @else 0 @endif %</span>
                                    </p>
                                </div>
                                <div class="col-md-2 col-6 LessonDetails d-flex align-items-center">
                                    <p class="mb-0">
                                        Duration
                                        <br>
                                        <span class="LessonDuration">{{$chapter->duration ?? 0}} Min</span>
                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 LessonDescription">
                                    {!!$chapter_description!!}
                                </div>
                            </div>
                        </div>

                         <div class="col-sm-3">
                            <div class="row">
                                <div class="col-12 LessonVid notAvailable">
                                    @if(!is_null($chapter->vimeo_embeded_code) || strlen($chapter->vimeo_embeded_code) > 5)
                                        <iframe class="ts-vimeo-video" src="{{ $chapter->vimeo_embeded_code }}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen="" ></iframe>
                                    @elseif(isset($chapter->vimeo_url))
                                        <iframe class="ts-vimeo-video" src="{{ str_replace('vimeo.com/','player.vimeo.com/video/',$chapter->vimeo_url) }}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen="" ></iframe>
                                    @else

                                    @endif

                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</section>
@endsection
