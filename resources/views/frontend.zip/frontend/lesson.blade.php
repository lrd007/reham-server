@extends('frontend.layouts.master')
@section('auth_content')
<!--Lessons-->
<section class="Lesson py-5 px-md-3" id="">
    <div class="container-fluid">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="#">My Programs</a></li>
                <li class="breadcrumb-item"><a href="#">Course 1</a></li>
                <li class="breadcrumb-item active" aria-current="page">Chapter 1</li>
                <li class="breadcrumb-item active" aria-current="page">Lesson 1</li>

            </ol>
        </nav>
        <h3 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing
            Elitr, Sed Diam
        </h3>
        <h6 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr,
            Sed
            Diam Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam
            Voluptua. At Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita Kasd
            Gubergren, No Sea Takimata Lorem Ipsum</h6>
        <div class="iframeContainer">
            <iframe src="https://player.vimeo.com/video/253989945" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
        </div>
        <form>
            <div class="row my-4">
                <div class="col-md-3 col-6">
                    <button type="button" class="btn btn-primary px-0 w-100 mb-3"><b>Next Lesson
                        </b>
                    </button>
                </div>
                <div class="col-md-3 col-6">

                    <button type="link" class="btn btn-primary  px-0 w-100  mb-3"><a href="Quiz.html" style="color: white;"><b>Attemp Quiz </b></a>

                    </button>
                </div>
                <div class="col-md-3 col-6">

                    <button type="link" class="btn btn-primary  px-0 w-100  mb-3"><a href="AddingStory.html" style="color: white;"><b>Upload Story
                            </b></a>

                    </button>
                </div>
                <div class="col-md-3 col-6">

                    <button type="button" class="btn btn-primary  px-0 w-100  mb-3"><b>Related Link
                        </b>
                    </button>
                </div>
            </div>
            <div class="row mt-3 justify-content-end mb-5">
                <div class="col-md-3 col-12 float-end text-center">

                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                    <label for="flexCheckDefault" style="color: #EA8BB9;"><b> Mark as Complete
                        </b></label>
                </div>
            </div>

            <div class="GreyTitle mb-3">
                Lesson Description
            </div>
            <h6 style="color: #939597 ;">Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing
                Elitr,
                Sed
                Diam Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed
                Diam
                Voluptua. At Vero Eos Et Accusam Et Justo Duo Dolores Et Ea Rebum. Stet Clita
                Kasd
                Gubergren, No Sea Takimata Lorem Ipsum</h6>
            <div class="GreyTitle mb-3 mt-5">
                Audio File
            </div>

            <div class="AudioFile">
                <div class=" d-flex m-auto">

                    <audio controls class="w-100 " id="AudioSound" controlsList="nodownload noplaybackrate">
                        <source src="https://media.geeksforgeeks.org/wp-content/uploads/20190531165842/Recording1514.ogg" type="audio/ogg">
                        <source src="https://media.geeksforgeeks.org/wp-content/uploads/20190531165842/Recording1514.mp3" type="audio/mpeg">
                        Your browser does not support the audio element.
                    </audio>
                </div>

            </div>

        </form>
        <div class="row my-5 DownloadAudio">
            <div class="col-sm-3 col-6 text-center">
                <a href="AudioFile.PDF">Download Pdf</a>
            </div>
            <div class="col-sm-3 col-6 text-center">

                <a href="AudioFile.text">Download Text</a>

            </div>
            <div class="col-sm-3 col-6 text-center">

                <a href="AudioFile.mp3">Download .mp3</a>

            </div>
            <div class="col-sm-3 col-6 text-center">
                <a href="AudioFile.mp4">Download .mp4</a>

            </div>
        </div>
        <!--Leave A COmment-->
        <form>
            <div class="row mt-5">

                <div class="col-12 px-3 mb-4">
                    <label for="Comment" class="form-label w-100" style="color: #939597;font-size: 20px;"><b>Add a Comment <span class="float-end">423</span></b> </label>

                    <textarea name="Comment" id="Comment" class="form-control p-5" cols="30" rows="10" required placeholder="Comment"></textarea>
                </div>

            </div>
            <button type="submit" class="btn btn-primary float-end"><b>Submit Commment </b>
            </button>
        </form>
        <br>
        <!--Comment section-->
        <div class="row  d-flex justify-content-center align-items-center  mt-5">
            <div class="col-md-12">
                <div class="card border-0">
                    <div class="p-3">
                        <div class="GreyTitle mb-2">
                            Reviews
                        </div>
                    </div>
                    <div class="CommentCards">
                        <div class="UserComment">
                            <div class="card mb-3 p-3">
                                <div class="row g-0 justify-content-center align-items-center">
                                    <div class="col-2 text-center">
                                        <img src="frontend/images/CommentImage.png" class="img-fluid rounded-start w-75" alt="Comment Image">
                                    </div>
                                    <div class="col-10">
                                        <div class="card-body pe-0">
                                            <p class="card-title UserCommentName">User Name
                                                <span class="CommentDate ms-3">21/02/2022</span>
                                            </p>

                                            <p class="card-text stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                                <span>(5.0)</span>
                                            </p>
                                            <p class="card-text CommentContent">Lorem Ipsum
                                                Dolor
                                                Sit Amet, Consetetur Sadipscing Elitr, Sed Diam
                                                Nonumy Eirmod Tempor Invidunt Ut Labore Et
                                                Dolore
                                                Magna Aliquyam Erat, Sed Diam Voluptua. At Vero
                                                Eos
                                                Et Accusam Et Justo Duo Dolores Et Ea Rebum.
                                                Stet
                                                Clita Kasd Gubergren, No Sea Takimata</p>
                                            <div class="card-buttons">
                                                <button type="button" class="btn btn-primary LikeBtn me-3">
                                                    <i class="fa-solid fa-thumbs-up me-1"></i>
                                                    34
                                                </button>
                                                <button type="button" id="replyOne" class="btn btn-primary ReplyBtn">
                                                    Reply
                                                </button>
                                            </div>

                                        </div>
                                    </div>
                                    <!--Reply Form-->
                                    <form id="ReplyFormOne">
                                        <div class="row mt-3 ps-5">

                                            <div class="col-12 px-3 mb-4">
                                                <label for="Comment" class="form-label w-100" style="color: #939597;font-size: 20px;"><b>Reply <span class="float-end">1</span></b> </label>

                                                <textarea name="Comment" id="Comment" class="form-control p-5" cols="30" rows="10" required placeholder="Comment"></textarea>
                                            </div>

                                        </div>
                                        <button type="submit" class="btn btn-primary float-end"><b>Submit reply </b>
                                        </button>
                                    </form>
                                </div>

                                <!--Reply To a comment-->
                                <div class="ReplyComment">
                                    <div class="card mb-3 p-3  float-end">
                                        <div class="row g-0 justify-content-center align-items-center">
                                            <div class="col-2 text-center">
                                                <img src="frontend/images/CommentImage.png" class="img-fluid rounded-start w-75" alt="Comment Image">
                                            </div>
                                            <div class="col-10">
                                                <div class="card-body pe-0">
                                                    <p class="card-title UserCommentName">User
                                                        Name
                                                        <span class="CommentDate ms-3">21/02/2022</span>
                                                    </p>

                                                    <p class="card-text stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                                        <span>(5.0)</span>
                                                    </p>
                                                    <p class="card-text CommentContent">Lorem
                                                        Ipsum
                                                        Dolor Sit Amet, Consetetur Sadipscing
                                                        Elitr,
                                                        Sed Diam Nonumy Eirmod Tempor Invidunt
                                                        Ut
                                                        Labore Et Dolore Magna Aliquyam Erat,
                                                        Sed
                                                        Diam Voluptua. At Vero Eos Et Accusam Et
                                                        Justo Duo Dolores Et Ea Rebum. Stet
                                                        Clita
                                                        Kasd Gubergren, No Sea Takimata</p>
                                                    <div class="card-buttons">
                                                        <button type="button" class="btn btn-primary LikeBtn me-3">
                                                            <i class="fa-solid fa-thumbs-up me-1"></i>
                                                            34
                                                        </button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
@endsection