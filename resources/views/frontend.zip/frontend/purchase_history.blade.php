@extends('frontend.layouts.master')
@section('auth_content')
<section class="PurshaseHistoryBody py-5">
    <div class="container-fluid px-md-5">
        <div class="card mb-5 border-0">
            <div class="row g-0">
                <div class="col-md-1 col-2 d-flex  align-items-center title mb-0">
                    <img src="frontend/images/logo.svg" alt="" class="w-100">
                </div>
                <div class="col-10">
                    <div class="card-body pe-0 ps-2">
                        <h4 class="card-title WhiteTitle"><b>Reham</b> </h4>
                        <h5 class="card-text">Reham@Mail.Com</h5>
                        <h5 class="card-text">(207)701-9820</h5>

                    </div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-6 mt-md-5">
                <div class="card mb-5 border-0">
                    <div class="row g-0">
                        <div class="col-12">
                            <div class="card-body pe-0 ps-2">
                                <h4 class="card-title WhiteTitle"><b>Bill To</b> </h4>
                                <h5 class="card-text">User Name</h5>
                                <h5 class="card-text">UserEmail@gmail.com</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 mt-md-5 mt-3">
                <div class="card mb-5 border-0 float-end">
                    <div class="row g-0">
                        <div class="col-12">
                            <div class="card-body pe-0 ps-2">
                                <h4 class="card-title WhiteTitle"><b>Purshase Date</b> </h4>
                                <h5 class="card-text">16/7/2022</h5>
                                <h5 class="card-text">Payment Method: <b>Paypal</b></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row TablePart my-4 p-lg-5 p-md-2">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Course</th>
                        <th scope="col">Date</th>
                        <th scope="col">Price</th>
                        <th scope="col">Payment Type</th>
                        <th scope="col">Invoice</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row" class="pt-md-4">lorem ipsum dolor sit </th>
                        <td class="pt-md-4">18/04/2012</td>
                        <td class="pt-md-4">361$</td>
                        <td class="pt-md-4">Paypal</td>
                        <td class="pt-md-4 "><span class="DownloadBtnTabel">Download</span> </td>




                    </tr>
                    <tr>
                        <th scope="row">lorem ipsum dolor sit ammet</th>
                        <td>20/12/2022</td>
                        <td>234$</td>
                        <td>Master Card</td>
                        <td><span class="DownloadBtnTabel">Download</span> </td>





                    </tr>
                    <tr>
                        <th scope="row">lorem ipsum dolor sit </th>
                        <td>05/06/2002</td>
                        <td>932$</td>
                        <td>Visa Card</td>
                        <td><span class="DownloadBtnTabel">Download</span> </td>
                    </tr>
                    <tr>
                        <th scope="row">lorem ipsum dolor sit</th>
                        <td>30/09/2021</td>
                        <td>20$</td>
                        <td>Master Card</td>
                        <td><span class="DownloadBtnTabel">Download</span> </td>

                    </tr>
                </tbody>
            </table>
        </div>
        <h4 class="WhiteTitle"><b>Grand Total <span class="float-end">5000$</span></b> </h4>

    </div>
</section>
@endsection