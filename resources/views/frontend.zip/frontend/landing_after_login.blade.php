@extends('frontend.layouts.master')
@section('content')
<!-- Profile Modal -->
<div class="modal " id="ProfileModal" tabindex="2" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="z-index: 200000 !important;">
        <div class="modal-content  RightTopCorner  p-md-5 ">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-x"></i></button>
            </div>
            <div class="modal-body">
                <div class="card mb-3 border-0">
                    <div class="row g-0">
                        <div class="col-3 d-flex justify-content-center align-items-center title mb-0" style="font-size: 80px;">
                            <div class="circle">
                                <img src="frontend/images/logo.svg" alt="">
                            </div>
                        </div>
                        <div class="col-9">
                            <div class="card-body pe-0 ps-2">
                                <h1 class="card-title GreyTitle"><b>Vincent Coleman</b> </h1>
                                <h5 class="card-text" style="color: #939597;">vincent@gmail.com</h5>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="list-group mt-4">
                    <a href="Profile.html" class="list-group-item list-group-item-action">Update Profile</a>
                    <a href="Payment.html" class="list-group-item list-group-item-action">Payment Method</a>
                    <a href="ResetPassword.html" class="list-group-item list-group-item-action">Change Password</a>
                    <a href="Legal.html" class="list-group-item list-group-item-action">Legal FAQs</a>
                    <a href="TechnicalSupport.html" class="list-group-item list-group-item-action">Technical
                        Support</a>
                    <a href="#" class="list-group-item list-group-item-action" data-bs-toggle="modal" data-bs-target="#LogOutModal" data-bs-dismiss="modal" aria-label="Close">Log Out</a>
                </div>
            </div>

        </div>
    </div>
</div>

<!--LogOut Modal -->
<div class="modal fade" id="LogOutModal" tabindex="-1" aria-labelledby="LogOutModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-5  RightTopCorner">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-x"></i></button>
            </div>
            <div class="modal-body text-center">
                <div class="GreyTitle"> Logout</div>
                <h5 class="my-4" style="color: #939597;">Are you sure you want to exit.</h5>
                <br>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-primary me-5">No</button>
                    <button type="button" class="btn btn-primary">Yes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="SideNav p-lg-5 py-4  BGwhite position-relative" id="SideNav">
    <div class="container-fluid">
        <div class="row ">
            <div class="d-flex justify-content-end">
                <div class="col-lg-3 d-none d-lg-block ">
                    <div class="Scrollable-Part">
                        <label for="ProgressBar" class="text-center w-100 mb-2 ProgressBarLabel"> 25%</label>

                        <div class="progress   w-75 text-center mx-auto mb-3 ">

                            <div class="progress-bar progress-bar-striped bg-success" id="ProgressBar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <div class="Scroll overflow-scroll">
                                <a href="index.html">
                                    <button class="nav-link active HideProgress" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
                                        Homepage
                                    </button>
                                </a>

                                <!--My Program Side Button-->
                                <div class="accordion" id="accordionExample">

                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingOne">




                                            <button class="nav-link ShowProgress" id="v-pills-AllPrograms-tab" data-bs-toggle="pill" data-bs-target="#v-pills-AllPrograms" type="button" role="tab" aria-controls="v-pills-AllPrograms" aria-selected="false">
                                                <a href="AllPrograms.html" class="w-100 h-100 p-0">
                                                    My Programs
                                                </a>
                                                <span class="accordion-button collapsed justify-content-between" href="AllPrograms.html" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                    <i class="fa-solid fa-chevron-down float-end"></i>

                                                </span>
                                            </button>

                                        </h2>

                                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">

                                                <!--Program Accordion-->
                                                <div class="accordion ps-2 mb-3" id="ProgramAccordion">
                                                    <!--Program 1-->
                                                    <div class="accordion-item">
                                                        <h2 class="accordion-header" id="Program1">


                                                            <button class="nav-link ShowProgress" id="v-pills-programOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne" type="button" role="tab" aria-controls="v-pills-programOne" aria-selected="false">
                                                                <a href="Course.html">
                                                                    Course 1
                                                                </a>
                                                                <span class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#Program1Collapse" aria-expanded="false" aria-controls="Program1Collapse">
                                                                    <i class="fa-solid fa-chevron-down float-end"></i>
                                                                </span>
                                                            </button>

                                                        </h2>
                                                        <div id="Program1Collapse" class="accordion-collapse collapse" aria-labelledby="Program1" data-bs-parent="#Program1">
                                                            <div class="accordion-body">
                                                                <!--COurse Accordion-->
                                                                <div class="accordion mt-2" id="CourseAccordion">

                                                                    <div class="accordion-item">
                                                                        <h2 class="accordion-header" id="CourseOne">



                                                                            <button class="nav-link ShowProgress" id="v-pills-programOne-CourseOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne-CourseOne" type="button" role="tab" aria-controls="v-pills-programOne-CourseOne" aria-selected="false">
                                                                                <a href="Chapter.html">
                                                                                    1. Chapter
                                                                                </a>
                                                                                <span class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#CourseOneCollapse" aria-expanded="false" aria-controls="CourseOneCollapse">
                                                                                    <i class="fa-solid fa-chevron-down float-end"></i>
                                                                                </span>
                                                                            </button>


                                                                        </h2>
                                                                        <div id="CourseOneCollapse" class="accordion-collapse collapse" aria-labelledby="CourseOne" data-bs-parent="#CourseAccordion">
                                                                            <div class="accordion-body">

                                                                                <button class="nav-link ShowProgress" id="v-pills-GetStarted-tab" data-bs-toggle="pill" data-bs-target="#v-pills-GetStarted" type="button" role="tab" aria-controls="v-pills-GetStarted" aria-selected="false">
                                                                                    <a href="GetStarted.html">
                                                                                        Get Started
                                                                                    </a>
                                                                                </button>

                                                                                <button class="nav-link ShowProgress" id="v-pills-programOne-CourseOne-ChapterOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne-CourseOne-ChapterOne" type="button" role="tab" aria-controls="v-pills-programOne-CourseOne-ChapterOne" aria-selected="false">
                                                                                    <a href="Lesson.html">
                                                                                        1. Lesson
                                                                                    </a>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>


                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--Program 2 -->
                                                    <div class="accordion-item">
                                                        <h2 class="accordion-header" id="Program2">



                                                            <button class="nav-link ShowProgress" id="v-pills-programTwo-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programTwo" type="button" role="tab" aria-controls="v-pills-programTwo" aria-selected="false">
                                                                <a href="Course.html">
                                                                    Course 2
                                                                </a>
                                                                <span class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#Program2Collapse" aria-expanded="false" aria-controls="Program2Collapse">
                                                                    <i class="fa-solid fa-chevron-down float-end"></i>
                                                                </span>
                                                            </button>

                                                        </h2>
                                                        <div id="Program2Collapse" class="accordion-collapse collapse" aria-labelledby="Program2" data-bs-parent="#ProgramAccordion">
                                                            <div class="accordion-body">
                                                                <!--COurse Accordion-->
                                                                <div class="accordion mt-2" id="CourseAccordion">

                                                                    <div class="accordion-item">
                                                                        <h2 class="accordion-header" id="CourseOneProgram2">

                                                                            <button class="nav-link ShowProgress" id="v-pills-programTwo-CourseTwo-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programTwo-CourseTwo" type="button" role="tab" aria-controls="v-pills-programTwo-CourseTwo" aria-selected="false">
                                                                                <a href="Chapter.html">
                                                                                    1. Chapter
                                                                                </a>
                                                                                <span class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#CourseOneProgram2Collapse" aria-expanded="false" aria-controls="CourseOneProgram2Collapse">

                                                                                    <i class="fa-solid fa-chevron-down float-end"></i>
                                                                                </span>
                                                                            </button>

                                                                        </h2>
                                                                        <div id="CourseOneProgram2Collapse" class="accordion-collapse collapse" aria-labelledby="CourseOneProgram2" data-bs-parent="#CourseOneProgram2">
                                                                            <div class="accordion-body">
                                                                                <button class="nav-link ShowProgress" id="v-pills-programOne-CourseOne-ChapterOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne-CourseOne-ChapterOne" type="button" role="tab" aria-controls="v-pills-programOne-CourseOne-ChapterOne" aria-selected="false">
                                                                                    <a href="Lesson.html">

                                                                                        1. Lesson
                                                                                    </a>
                                                                                </button>

                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a href="WhishList.html"><button class="nav-link HideProgress" id="v-pills-whishlist-tab" data-bs-toggle="pill" data-bs-target="#v-pills-whishlist" type="button" role="tab" aria-controls="v-pills-whishlist" aria-selected="false">Whishlist
                                    </button>
                                </a>
                                <a href="Suggestions.html"><button class="nav-link HideProgress" id="v-pills-Suggestions-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Suggestions" type="button" role="tab" aria-controls="v-pills-Suggestions" aria-selected="false">Suggested
                                        Courses</button>
                                </a>
                                <a href="FAQS.html"> <button class="nav-link HideProgress" id="v-pills-FAQs-tab" data-bs-toggle="pill" data-bs-target="#v-pills-FAQs" type="button" role="tab" aria-controls="v-pills-FAQs" aria-selected="false">FAQs</button>
                                </a>
                                <a href="Calendar.html"> <button class="nav-link HideProgress" id="v-pills-Calendar-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Calendar" type="button" role="tab" aria-controls="v-pills-Calendar" aria-selected="false">Calendar</button>
                                </a>
                                <a href="InspiringSotries.html">
                                    <button class="nav-link HideProgress PinkNavLink" id="v-pills-Stories-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Stories" type="button" role="tab" aria-controls="v-pills-Stories" aria-selected="false">Inspiring
                                        Stories</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="SideNavSmall d-block d-lg-none">
                    <button class="btn btn-primary SmallSideNav" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling">menu<i class="fa-solid fa-chevron-right"></i>
                    </button>
                    <div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">

                        <div class="offcanvas-body d-flex flex-column justify-content-center align-items-center">
                            <label for="ProgressBar" class="text-center w-100 mb-2 ProgressBarLabel"> 25%</label>

                            <div class="progress   w-75 text-center mx-auto mb-3 ">

                                <div class="progress-bar progress-bar-striped bg-success" id="ProgressBar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="nav flex-column nav-pills  RightBottomCorner" id="v-pills-tab" role="tablist" aria-orientation="vertical">

                                <button class="nav-link active HideProgress" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Homepage</button>

                                <!--My Program Side Button-->
                                <div class="accordion" id="accordionExample">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingOne">
                                            <a class="accordion-button collapsed justify-content-between" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                <button class="nav-link ShowProgress" id="v-pills-AllPrograms-tab" data-bs-toggle="pill" data-bs-target="#v-pills-AllPrograms" type="button" role="tab" aria-controls="v-pills-AllPrograms" aria-selected="false">
                                                    My Programs <i class="fa-solid fa-chevron-down float-end"></i>

                                                </button>


                                            </a>
                                        </h2>
                                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">

                                                <!--Program Accordion-->
                                                <div class="accordion ps-2 mb-3" id="ProgramAccordion">
                                                    <!--Program 1-->
                                                    <div class="accordion-item">
                                                        <h2 class="accordion-header" id="Program1">
                                                            <a class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#Program1Collapse" aria-expanded="false" aria-controls="Program1Collapse">
                                                                <button class="nav-link ShowProgress" id="v-pills-programOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne" type="button" role="tab" aria-controls="v-pills-programOne" aria-selected="false">
                                                                    Course 1 <i class="fa-solid fa-chevron-down float-end"></i>

                                                                </button>
                                                            </a>
                                                        </h2>
                                                        <div id="Program1Collapse" class="accordion-collapse collapse" aria-labelledby="Program1" data-bs-parent="#Program1">
                                                            <div class="accordion-body">
                                                                <!--COurse Accordion-->
                                                                <div class="accordion mt-2" id="CourseAccordion">

                                                                    <div class="accordion-item">
                                                                        <h2 class="accordion-header" id="CourseOne">
                                                                            <a class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#CourseOneCollapse" aria-expanded="false" aria-controls="CourseOneCollapse">
                                                                                <button class="nav-link ShowProgress" id="v-pills-programOne-CourseOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne-CourseOne" type="button" role="tab" aria-controls="v-pills-programOne-CourseOne" aria-selected="false">
                                                                                    1. Chapter <i class="fa-solid fa-chevron-down float-end"></i>

                                                                                </button>

                                                                            </a>
                                                                        </h2>
                                                                        <div id="CourseOneCollapse" class="accordion-collapse collapse" aria-labelledby="CourseOne" data-bs-parent="#CourseAccordion">
                                                                            <div class="accordion-body">
                                                                                <button class="nav-link ShowProgress" id="v-pills-GetStarted-tab" data-bs-toggle="pill" data-bs-target="#v-pills-GetStarted" type="button" role="tab" aria-controls="v-pills-GetStarted" aria-selected="false">
                                                                                    Get Started
                                                                                </button>
                                                                                <button class="nav-link ShowProgress" id="v-pills-programOne-CourseOne-ChapterOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne-CourseOne-ChapterOne" type="button" role="tab" aria-controls="v-pills-programOne-CourseOne-ChapterOne" aria-selected="false">
                                                                                    1. Lesson
                                                                                </button>

                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>


                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--Program 2 -->
                                                    <div class="accordion-item">
                                                        <h2 class="accordion-header" id="Program2">
                                                            <a class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#Program2Collapse" aria-expanded="false" aria-controls="Program2Collapse">
                                                                <button class="nav-link ShowProgress" id="v-pills-programTwo-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programTwo" type="button" role="tab" aria-controls="v-pills-programTwo" aria-selected="false">
                                                                    Course 2 <i class="fa-solid fa-chevron-down float-end"></i>

                                                                </button>
                                                            </a>
                                                        </h2>
                                                        <div id="Program2Collapse" class="accordion-collapse collapse" aria-labelledby="Program2" data-bs-parent="#ProgramAccordion">
                                                            <div class="accordion-body">
                                                                <!--COurse Accordion-->
                                                                <div class="accordion mt-2" id="CourseAccordion">

                                                                    <div class="accordion-item">
                                                                        <h2 class="accordion-header" id="CourseOneProgram2">
                                                                            <a class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#CourseOneProgram2Collapse" aria-expanded="false" aria-controls="CourseOneProgram2Collapse">
                                                                                <button class="nav-link ShowProgress" id="v-pills-programTwo-CourseTwo-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programTwo-CourseTwo" type="button" role="tab" aria-controls="v-pills-programTwo-CourseTwo" aria-selected="false">
                                                                                    1. Chapter <i class="fa-solid fa-chevron-down float-end"></i>

                                                                                </button>

                                                                            </a>
                                                                        </h2>
                                                                        <div id="CourseOneProgram2Collapse" class="accordion-collapse collapse" aria-labelledby="CourseOneProgram2" data-bs-parent="#CourseOneProgram2">
                                                                            <div class="accordion-body">

                                                                                <button class="nav-link ShowProgress" id="v-pills-programOne-CourseOne-ChapterOne-tab" data-bs-toggle="pill" data-bs-target="#v-pills-programOne-CourseOne-ChapterOne" type="button" role="tab" aria-controls="v-pills-programOne-CourseOne-ChapterOne" aria-selected="false">
                                                                                    1. Lesson
                                                                                </button>

                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button class="nav-link HideProgress" id="v-pills-whishlist-tab" data-bs-toggle="pill" data-bs-target="#v-pills-whishlist" type="button" role="tab" aria-controls="v-pills-whishlist" aria-selected="false">Whishlist
                                </button>
                                <button class="nav-link HideProgress" id="v-pills-Suggestions-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Suggestions" type="button" role="tab" aria-controls="v-pills-Suggestions" aria-selected="false">Suggested
                                    Courses</button>
                                <button class="nav-link HideProgress" id="v-pills-FAQs-tab" data-bs-toggle="pill" data-bs-target="#v-pills-FAQs" type="button" role="tab" aria-controls="v-pills-FAQs" aria-selected="false">FAQs</button>
                                <button class="nav-link HideProgress" id="v-pills-Calendar-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Calendar" type="button" role="tab" aria-controls="v-pills-Calendar" aria-selected="false">Calendar</button>
                                <button class="nav-link HideProgress PinkNavLink" id="v-pills-Stories-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Stories" type="button" role="tab" aria-controls="v-pills-Stories" aria-selected="false">Inspiring Stories</button>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="tab-content col-lg-9 col-12 float-end" id="v-pills-tabContent">

                    <!--The Content Here-->
                    <!--The Content Here-->
                    <!--The Content Here-->
                    <!--The Content Here-->
                    <!--The Content Here-->
                    <!--The Content Here-->
                    <!--The Content Here-->
                    <!--The Content Here-->























                </div>
            </div>


        </div>

    </div>
</div>
@endsection