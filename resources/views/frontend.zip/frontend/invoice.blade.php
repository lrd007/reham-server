@extends('frontend.layouts.master')
@section('auth_content')
<!--Invoice-->
<Section class="LoginBody py-3 text-center " id="LoginBody">
    <img src="frontend/images/logo.svg" alt="logo" class="logo">
    <img src="frontend/images/LoginBg.svg" alt="LoginBg">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-12  d-flex  justify-content-center">
                <div class="LoginForm RightBottomCorner  ">
                    <p class="Invoicetext">Name: <span class="float-end"> UserName </span></p>

                    <p class="Invoicetext">email: <span class="float-end"> UserEmail@example.com </span>
                    </p>

                    <p class="Invoicetext">Payment Id: <span class="float-end"> 001 </span></p>
                    <p class="Invoicetext">Track Id: <span class="float-end"> 21212 </span></p>
                    <p class="Invoicetext">Amount: <span class="float-end"> 232kb </span></p>
                    <a href="AllPrograms.html">
                        <button type="submit" class="btn btn-primary mt-md-5 mt-3  position-relative w-100">Go to my
                            programs</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</Section>

<!--End Invoice -->
@endsection