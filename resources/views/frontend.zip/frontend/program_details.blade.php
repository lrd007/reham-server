@extends('frontend.layouts.master')
@auth
@section('auth_content')
@endauth

@guest
@section('content')
@endguest
<!--Header-->
<div class="alert alert-success alert-dismissible fade show cart-alert d-none" role="alert" style="z-index: 999999;position: sticky;top: 89px;">
    <strong>{{ __('words.Success') }}!</strong> {{__('words.Program')}} {{ __('words.add to cart success') }}.
</div>
<header class="header p-md-5 p-3 " id="header">
    <div class="container-fluid d-flex justify-content-center">
        <img src="{{asset('frontend/images/headerBg1.svg')}}" alt="" class="headerBg1">
        <img src="{{asset('frontend/images/headerBg2.svg')}}" alt="" class="headerBg2">

        <div class=" headerVid d-flex justify-content-center align-items-center">
            <div class="iframeContainer w-100 h-100" style="z-index: 10;">

                @if(!is_null($program->vimeo) || strlen($program->vimeo) > 5)
                    <iframe class="ts-vimeo-video" src="{{ GetVimeoFrameLink($program->vimeo) }}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen="" ></iframe>
                @elseif(isset($program->vimeo_url))
                    <iframe class="ts-vimeo-video" src="{{ GetVimeoFrameLink($program->vimeo_url) }}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen="" ></iframe>
                @else
                <iframe src="{{$program->vimeo}}" webkitallowfullscreen mozallowfullscreen allowfullscreen title="Video Title Here"></iframe>
                @endif
            </div>

        </div>
    </div>
</header>

<!--End Header-->
<!--CoursesDivs-->

<section class="CoursesDivs " id="CoursesDivs">



    <!--30 days Refund-->
    <div class="BGPink RefundDays">
        <div class="card ">
            <div class="row g-0">
                <div class="col-md-4 col-12 d-flex justify-content-center align-items-center p-3">
                    <img src="{{asset('frontend/images/Coin.png')}}" class="img-fluid rounded-start " alt="...">
                </div>
                <div class="col-md-8 col-12">
                    <div class="card-body">
                        <p class="card-text">

                                {{ __('words.warrant part 1') }}
                                {{$program->warranty}}
                                {{ __('words.warrant part 2') }}

                             </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End CoursesDivs-->

<!--Subscibe Section-->
<section class="Subscibe py-5">
    <div class="container">
        <div class="row ">
            <div class="col-12 d-flex flex-column justify-content-center">
                <button type="button" class="SubscribBTn btn btn-primary btn-lg mx-auto">
                    {{ __('words.Subscribe With') }} {{$amount}} {{ __('words.KD') }}
                    <img src="{{asset('frontend/images/SpecialOfferCardIconWhite.svg')}}" alt="">
                </button>
                <a href="#">
                    <div class="col-12 my-4 d-flex flex-row justify-content-center">
                        <div class="col-1 me-2">
                            <img src="{{asset('frontend/images/visa.svg')}}" alt="Visa Card" class=" w-100">
                        </div>
                        <div class="col-1  me-2">
                            <img src="{{asset('frontend/images/mastercard.svg')}}" alt="master Card" class=" w-100">
                        </div>
                        <div class="col-1  me-2">
                            <img src="{{asset('frontend/images/knet.png')}}" alt="knet Card" class=" w-100">
                        </div>
                        <img src="{{asset('frontend/images/paypal.svg')}}" alt="paypal " class=" w-auto">

                    </div>
                    <div class="row justify-content-center">

                        <div class="col-lg-1 col-4">
                            <img src="{{asset('frontend/images/payment-varified.svg')}}" alt="payment-varified" class="w-75 float-end">
                        </div>
                        <div class="col-md-5 col-8">
                            <h4 style="line-height:2.2; color: #767676;" class="text-center">
                                <b>{{ __('words.Verified Payment Methods') }} </b>
                            </h4>
                        </div>
                    </div>


                </a>
            </div>

        </div>
    </div>
</section>
<!--End Subscibe Section-->

<!--Program Agenda Section-->
<section class="ProgramAgenda py-5" id="ProgramAgenda">
    <div class="container-fluid">
        <div class="title text-center">
            {{ __('words.Program Agenda') }}
        </div>
        <div class="row my-4 px-3 ">
            <div class="col-md-5 col-6 BGwhite p-5">
                <p>{!! $program->{ 'description'. withLocalization() } !!}</p>
            </div>
            <div class="col-md-2 d-md-block d-none"></div>
            <div class="col-md-5 col-6 BGwhite p-5">
                <p>{!! $program->{ 'description'. withLocalization().'_2' } !!}</p>
            </div>
        </div>
        <nav>
            <div class="nav nav-tabs w-100" id="CourseDetailsTabs" role="tablist">
                @foreach($program->courses as $course)
                <button class="nav-link @if($loop->first) active @endif" id="nav-{{$loop->index}}-tab" data-bs-toggle="tab" data-bs-target="#nav-{{$loop->index}}" type="button" role="tab" aria-controls="nav-{{$loop->index}}" aria-selected="true"> {{ $course->{ 'name'. withLocalization() } }}</button>
                <!-- <button class="nav-link" id="nav-Two-tab" data-bs-toggle="tab" data-bs-target="#nav-Two" type="button" role="tab" aria-controls="nav-Two" aria-selected="false">Tab Two</button>
                <button class="nav-link" id="nav-Three-tab" data-bs-toggle="tab" data-bs-target="#nav-Three" type="button" role="tab" aria-controls="nav-Three" aria-selected="false">Tab Three</button> -->
                @endforeach
            </div>
        </nav>
        <div class="tab-content p-md-5 p-3" id="nav-tabContent">
            <!--Tab 1-->
            @foreach($program->courses as $course)
            <div class="tab-pane fade show @if($loop->first) active @endif" id="nav-{{$loop->index}}" role="tabpanel" aria-labelledby="nav-{{$loop->index}}-tab">
                <div class="GreyTitle">
                    {{ $course->{ 'name'. withLocalization() } }}
                </div>
                <div class="container PrgoramAgendaCards">
                    <div class="row justify-content-center">
                        @foreach($course->chapters as $chapter)
                        @foreach($chapter->lessons as $lesson)
                        <div class="col-lg-2 col-sm-4 col-6 mb-3">
                            <div class="card">
                                <img src="{{asset('frontend/images/ProgramAgendaImage.jpg')}}" class="card-img-top" alt="Program Agenda Image">
                                <div class="card-body py-0 px-2">
                                    <p class="card-text"> {{ $lesson->{ 'name'. withLocalization() } }}</p>
                                </div>
                            </div>
                        </div>
                        @endforeach
                        @endforeach
                    </div>
                </div>
            </div>
            @endforeach
            <!--Tab 1-->
        </div>
    </div>
</section>
<!--End Program Agenda Section-->

<!--Subscibe Section-->
<section class="Subscibe py-5">
    <div class="container">
        <div class="row ">
            <div class="col-12 d-flex flex-column justify-content-center">
                <button type="button" class="SubscribBTn btn btn-primary btn-lg mx-auto">
                    {{ __('words.Subscribe With') }} {{$amount}} {{ __('words.KD') }}
                    <img src="{{asset('frontend/images/SpecialOfferCardIconWhite.svg')}}" alt="">
                </button>
                <a href="#">
                    <div class="col-12 my-4 d-flex flex-row justify-content-center">
                        <div class="col-1 me-2">
                            <img src="{{asset('frontend/images/visa.svg')}}" alt="Visa Card" class=" w-100">
                        </div>
                        <div class="col-1  me-2">
                            <img src="{{asset('frontend/images/mastercard.svg')}}" alt="master Card" class=" w-100">
                        </div>
                        <div class="col-1  me-2">
                            <img src="{{asset('frontend/images/knet.png')}}" alt="knet Card" class=" w-100">
                        </div>
                        <img src="{{asset('frontend/images/paypal.svg')}}" alt="paypal " class=" w-auto">

                    </div>
                    <div class="row justify-content-center">

                        <div class="col-md-1 col-4">
                            <img src="{{asset('frontend/images/payment-varified.svg')}}" alt="payment-varified" class="w-75 float-end">
                        </div>
                        <div class="col-md-5 col-8">
                            <h4 style="line-height:2.2; color: #767676;" class="text-center">
                                <b>{{ __('words.Verified Payment Methods') }}</b>
                            </h4>
                        </div>
                    </div>


                </a>
            </div>

        </div>
    </div>
</section>
<!--End Subscibe Section-->

<!--Fixed Btn-->
<div class="fixedBtn mb-5">
    <div class="overlay">
        @if(auth()->user())
            <button type="button" class="SubscribBTn btn btn-primary btn-sm mx-auto" onclick="addCart()">
                {{ __('words.Subscribe With') }} {{$amount}} {{ __('words.KD') }}
                <img src="{{asset('frontend/images/SpecialOfferCardIconWhite.svg')}}" alt="">
            </button>
        @else
            <a href="{{route('user.login')}}">
                <button type="button" class="SubscribBTn btn btn-primary btn-sm mx-auto">
                    {{ __('words.Subscribe With') }} {{$amount}} {{ __('words.KD') }}
                    <img src="{{asset('frontend/images/SpecialOfferCardIconWhite.svg')}}" alt="">
                </button>
            </a>
        @endif
    </div>
</div>
<script>
    function addCart(){
        const program_id = window.location.href.split('/').slice(-1).pop();
        $.ajax
        ({
            url: '/add-cart/'+program_id,
            type: 'get',
            success: function(result)
            {
                $('.cart-alert').removeClass('d-none');
                console.log(result.cart_item);
                $('#cart_item').text(result.cart_item);
                // const get_cart = localStorage.getItem('program_details');
                // const program_details = get_cart ? JSON.parse(get_cart) : [];
                // if(program_details.findIndex(e => e === program_id ) == -1) {
                //     program_details.push(program_id);
                // }
                // localStorage.setItem('program_details', JSON.stringify(program_details));
                // const updated_get_cart = localStorage.getItem('program_details');
                // const update_get_cart_count = JSON.parse(updated_get_cart).length;
            }
        });
    }
</script>
@endsection
